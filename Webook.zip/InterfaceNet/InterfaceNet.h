






#ifndef _INTERFACENET_H_
#define _INTERFACENET_H_    //#endif  // _INTERFACENET_H_ //

//�ṹ����INTERFACENET.CPP��ʵ��
#ifdef  _INTERFACENET_CPP_    //#endif  // _INTERFACENET_CPP_ //
#define INTERFACENET_EXTERN 
#else 
#define INTERFACENET_EXTERN extern 
#endif  // _INTERFACENET_CPP_ //

#include <Windows.h>
#include  "res/resource.h"

#define WND_CLASS "SIMPLEINTERFACENET"



#include "qLog.h"


HWND& GetMainWnd();
HWND& GetMainDlg();


#ifdef _WINDOWS        // #ifndef _CONSOLE
//#define printf showMsg  // Printf
#endif  



INTERFACENET_EXTERN HMENU hPopMenu; 




BOOL GetFolder(LPTSTR szBuf, LPCTSTR szDefDir = 0L, BOOL bFolderOnly = false);


BOOL GetFileName(LPWSTR szFileName,HWND hWnd=0, BOOL bSave=false,LPCWSTR szFilter=0L,LPCWSTR szInitial=0L); 
BOOL GetFileName(LPTSTR szFileName,HWND hWnd=0, BOOL bSave=false,LPCTSTR szFilter=0L,LPCTSTR szInitial=0L); 






 

#endif  // _INTERFACENET_H_ //






