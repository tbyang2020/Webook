﻿

#define _BROWSE_CPP_  // 利用GetOpenFileName, 提供文件[夹]浏览界面 BrowseProc. 

// .\,.\Interface_Browse,.\Interface_Browse\res,.\WebPage 



#pragma warning(disable:4996)


//bool  SEARCH_DIRECTORY = 1;    // 否则, 仅搜索选定文件

#define  SEARCH_DIRECTORY  1  

#define  WM_DRAW  (WM_USER+0x101)   // 以便不截获 "MDICLIENT" 的窗口过程  



  

#include "../InterfaceNet/InterfaceNet.h"

#include "../InterfaceNet/qTrace.h"

#include <Windows.h>
#include <stdio.h>
#include <io.h>  // write 

#include <locale.h>  // setlocale 

#include <assert.h>

#include "../InterfaceNet/res/resource.h"
#include "Browse.h"


// #include "../InterfaceNet/FileEx.h"
 
#include "Interact.h"

#include <CommCtrl.h>



#include <io.h>              // read 
#include <fcntl.h>           // _O_BINARY
#include <sys/stat.h>        // _S_IREAD

 
 
   

 

 
 
// wchar_t g_Path[256];     // 记录程序所在目录(上一级)   // 放在BrowseProc之内, static  
// char    a_Path[256]; 







// 预处理 WM_SIZE 消息. 

WNDPROC OldBrowseProc;    // Intercept GetOpenSaveFileName's Window Procedure.  预处理IDOK=1键,仅改用为搜索按钮. 更改其绘制代码.  

UINT_PTR CALLBACK InterceptBrowse(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam){

WORD wId,wEvent; 

switch(uMsg) {

case WM_CLOSE:{ return true; }break;   // √  

case WM_PAINT:   

CallWindowProc(OldBrowseProc,hWnd,uMsg, wParam, lParam); 

SendMessage(GetMainWnd(), WM_DRAW,0,0);     

return true;
break; 





#if INTERCEPT_MORE


case WM_DRAWITEM:{   
#if M_BACKUP
LPDRAWITEMSTRUCT lpdis= (LPDRAWITEMSTRUCT) lParam; 

bool bReady=true;  //=IsWindowEnabled(lpdis->hwndItem);  // (GetFileAttributesW(g_szFile)&FILE_ATTRIBUTE_DIRECTORY); 

DWORD dwStatus=0; 
if( hThread!=0L){ if( !GetExitCodeThread(hThread,&dwStatus) ) eInfo("GetExitCodeThread"); 
if(dwStatus==STILL_ACTIVE)bReady=false; }

if(lpdis->itemState & ODS_SELECTED){ DrawEdge(lpdis->hDC,&lpdis->rcItem,BDR_SUNKENINNER,BF_SOFT|BF_RECT);
DrawFocusRect(lpdis->hDC,&lpdis->rcItem); 
}else DrawEdge(lpdis->hDC,&lpdis->rcItem,BDR_RAISEDINNER,BF_SOFT|BF_RECT);

if(bReady){ SetTextColor(lpdis->hDC,0xFF0000); 
DrawText(lpdis->hDC,"执行任务",8,&lpdis->rcItem,DT_CENTER|DT_VCENTER|DT_SINGLELINE); 
}else{ SetTextColor(lpdis->hDC,0xc0c0c0); // 0xc0c0c0
DrawText(lpdis->hDC,"终止任务",8,&lpdis->rcItem,DT_CENTER|DT_VCENTER|DT_SINGLELINE); 
}

#endif  // M_BACKUP 
return true; 
}break; 


//case WM_KEYDOWN:MessageBox(0,"Key down!","InterceptBrowse",0);break;  // No!
case WM_COMMAND:
  wId=LOWORD(wParam),wEvent=HIWORD(wParam);
switch(wId) {

case IDOK:{  break;  
  static OFNOTIFYW ofn = { {(HWND)102,102,CDN_FILEOK},0L,0L };   // hwndFrom=0, idFrom=0 是假消息标志
  SendMessage(getDlg(), WM_NOTIFY, 0, (long)&ofn); 
}break;


// case 0x0443:{}break;  // 查找范围(&I)                         





default:break;  // switch(wId)
}break; //case WM_COMMAND;


#endif  // INTERCEPT_MORE




} // switch(uMsg);

return CallWindowProc(OldBrowseProc,hWnd,uMsg, wParam, lParam); // not reached!
} 







// 确定App 的主目录. 初始化 g_Path、a_Path. 
// 注意, 由于返回值不是 const WCHAR*, 因此, 使用该函数得到的不一定是 App Path !

wchar_t* GetAppPathW(){
static wchar_t* g_path=0;    // App path 始终不变.  


if(!g_path){ g_path=new wchar_t[256]; 


#if USE_CMDLINE

wchar_t*cw=GetCommandLineW();  // MessageBoxW(0,cw,L"GetCommandLineW",0);  // 空格分隔  name.exe  搜索内容  
wchar_t*p=wcschr(cw,'\"'); if(p) p++; else p=cw; while(*p==0x20)p++; 



wchar_t*q=wcsrchr(p,'\"'); if(q) *q=0; 
q=wcsrchr(p,'\\'); if(q) *q=0; 
q=wcsrchr(p,'\\'); if(q) *q=0; 

wcscpy(g_path, p);  // 记录程序所在目录(上一级), 以便于指定临时文件、搜索记录等等    


#else

GetModuleFileNameW(0,g_path, 256);  
wchar_t*p=wcsrchr(g_path,'\\'); if(p) *p=0;   

p= wcsstr(g_path,L"\\Debug");  if(p) *p=0;  // 调试期间, 跳出  [Debug]

#endif    //  USE_CMDLINE

}    // if 0  


return g_path;
}






HWND CreateBS(HWND hParent,  void*ps){  // =0//=0  

_wsetlocale(0, L"chs");  // 否则 fwprintf(.."%S", (char*)...) 不能正确转换中文 MBCS 串为 Unicode 串

// GetModuleFileNameW(hInstance,szModule,MAX_PATH); WORD*p=wcsrchr(szModule,'\\'); if(p)*p=0;

wchar_t*cw=GetCommandLineW();  // MessageBoxW(0,cw,L"GetCommandLineW",0);  // 空格分隔  name.exe  搜索内容  
wchar_t*p=wcschr(cw,'\"'); if(p) p++; else p=cw; while(*p==0x20)p++; 

wchar_t*q=wcsrchr(p,'\"'); if(q) *q=0; 
q=wcsrchr(p,'\\'); if(q) *q=0; 
q=wcsrchr(p,'\\'); if(q) *q=0; 


DWORD thID;   // Browse(p) 阻塞! 
HANDLE hThread=CreateThread(0,0,(LPTHREAD_START_ROUTINE)Browse,p,0,&thID);

int ic=0;  
while( !IsWindow( GetBS() ) ){ ic++; if(ic>30) break;  Sleep(100); }



if(hParent) {
long w=GetWindowLong(GetBS(),GWL_STYLE);
// w|=WS_CHILD|WS_SIZEBOX;  //|WS_BORDER |WS_CAPTION |WS_CLIPCHILDREN|WS_CLIPSIBLINGS;   //  
// SetWindowLong(GetBS(),GWL_STYLE,w); 
SetParent(GetBS(),hParent);
}

return GetBS();
}


 





bool Browse(LPCWSTR szDir){  // ,LPCWSTR sFilter=0L 

wchar_t*  szFilter = new wchar_t[256]; 
  
wchar_t*p=szFilter; 
wcscpy(p,L"All Files (*.*)|*.*|Folders Only|*.null|");  // 这里认为没有文件使用扩展名 null 

while(*p!=0){if(*p=='|') *p=0;p++;}
 
OPENFILENAMEW ofn={0}; ZeroMemory(&ofn,sizeof(OPENFILENAME));
ofn.lpstrFilter=szFilter;
ofn.nMaxFile=MAX_PATH*100;  // 最多100个文件;//
ofn.lpstrFile=new wchar_t[MAX_PATH*100];   *ofn.lpstrFile=0; 

ofn.lStructSize=sizeof(OPENFILENAMEW);
ofn.hInstance=GetModuleHandle(0); 
// ofn.hwndOwner=0;  //getWnd();


if(szDir!=NULL) ofn.lpstrInitialDir=szDir;
else  ofn.lpstrInitialDir = 0L;    //  依当前程序所在目录为初始目录


ofn.Flags=OFN_EXPLORER|OFN_ENABLEHOOK |OFN_ENABLETEMPLATE; //    IDD_DIALOG1 has to have a WS_CHILD style!
ofn.Flags|=
OFN_FILEMUSTEXIST
|OFN_ALLOWMULTISELECT // |OFN_SHOWHELP|;  // 允许选中多个文件, e.g. (Exempli gratia.) D:\实用程序\"FileEx.h" "FileEx.cpp" 
|OFN_ENABLESIZING;
ofn.Flags|=OFN_HIDEREADONLY;
//ofn.Flags|=OFN_NOREADONLYRETURN;

ofn.Flags|=OFN_SHAREAWARE;     // 警告打开冲突

//ofn.Flags|=OFN_SHOWHELP;     // 帮助按钮
ofn.lpTemplateName=MAKEINTRESOURCEW(IDD_DIALOG0);

ofn.lpstrTitle =L"搜索范围";  // szTitle;

ofn.lpfnHook=(LPOFNHOOKPROC)BrowseProc;

ofn.FlagsEx=OFN_EX_NOPLACESBAR;   // 不显示快速浏览等图标


BOOL br=GetOpenFileNameW(&ofn); 

delete[] ofn.lpstrFile;
delete[] szFilter;

return br;
}







// vəˈkeɪt, 辅助函数, 清除特定字符. 要求 sz 以 0 结尾 
char* vacate(char*sz, char c){ 
if (!sz) return 0; 


int ic = 0;
char*p = sz;   
while (*p){ ic++; p++; }


char*po=sz;

p = strchr(sz,c); 
 
while (p){

memmove(p,p+1, ic-(p-po));  
ic--;

p = strchr(p,c);
} // while 

return sz; 
}

// vəˈkeɪt, 辅助函数, 清除特定字符. 要求 sz 以 0 结尾 
wchar_t* vacate(wchar_t*sz, WORD c){ 
if (!sz) return 0; 


int ic = 0;
wchar_t*p = sz;   
while (*p){ ic++; p++; }


wchar_t*po=sz;

p = wcschr(sz,c); 
 
while (p){

memmove(p,p+1, 2*(ic-(p-po)));  
ic--;

p = wcschr(p,c);
} // while 

return sz; 
}



//  ListView_GetItemText Unicode 版本 

#define ListView_GetItemTextW(hwndLV, i, iSubItem_, pszText_, cchTextMax_) \
{ LV_ITEMW _macro_lvi;\
  _macro_lvi.iSubItem = (iSubItem_);\
  _macro_lvi.cchTextMax = (cchTextMax_);\
  _macro_lvi.pszText = (pszText_);\
  SNDMSG((hwndLV), LVM_GETITEMTEXTW, (WPARAM)(i), (LPARAM)(LV_ITEM *)&_macro_lvi);\
}





//  全局变量, 公用于 m_BrowseProcW,  InterceptBrowse  

// 对话框主程序:  The OFNHookProc hook procedure 

 
UINT_PTR CALLBACK BrowseProc(HWND hdlg,UINT uiMsg,WPARAM wParam,LPARAM lParam) {


// static wchar_t g_Path[256];   // 其他函数要用到 g_Path  

static HANDLE hThread=0;
static wchar_t g_File[260*5];


static HINSTANCE hInst = GetModuleHandle(0); 

switch(uiMsg) {


case WM_INITDIALOG:{
      
GetMainDlg()=hdlg;  
HWND hp=GetParent(hdlg);  // 重点预处理IDOK=1键,仅改用为搜索按钮.  -- 没用到
GetBS()=hp;   

#if INTERCEPT_WNDPROC|1   // 

OldBrowseProc=(WNDPROC)SetWindowLongW(hp,GWL_WNDPROC,(LONG)InterceptBrowse);  \
if(!OldBrowseProc)eInfo("SetWindowLongW");   // else MessageBox(0,"InterceptBrowse","Intercepted!",0);

#endif   // INTERCEPT_WNDPROC  


// SendMessageW(hp,CDM_SETCONTROLTEXT, IDOK,(long)L"展开(&O)");   // GetOpenFileNameW 要求 Unicode 
HWND hItem=GetDlgItem(hp, IDCANCEL);  ShowWindow(hItem, SW_HIDE); 


#if SET_FONT|1

HFONT hArFont=CreateFont(20, 8,  0,0,  FW_NORMAL,  0,0,0,0, 0,0,0,0,"Traditional Arabic Fixed");  //  16, 7, "Arial";  18,8,"Traditional Arabic" "Simplified Arabic Fixed";
if(hArFont==NULL) qTrace("CreateFont");  \
SendDlgItemMessage(hdlg,IDC_COMBO2,WM_SETFONT,(WPARAM)hArFont,true);  


#endif    // SET_FONT

// MoveItems(hp); 
 







// 加载搜索历史记录  
hItem = GetDlgItem(hdlg, IDC_COMBO2);
// SendMessageW(hItem, CB_INSERTSTRING, 0, (long)L"السَّلام عَلَيْكُمُ!");   
SendMessageW(hItem, CB_ADDSTRING, 0, (long)L"真主的恩惠");    
SendMessageW(hItem, CB_SETCURSEL, 0, 0); 
SendMessageW(hItem, CB_ADDSTRING, 0, (long)L"获得");    


LoadHistory(hdlg, IDC_COMBO11, L"Search_History.txt"); 
 

 
}break;
 

case WM_CLOSE: MessageBox(0,"WM_CLOSE",0,0); break;    // ×  



case WM_DESTROY:{  
if(0)MessageBox(0,"Also ok!",0,0);   // √   

wchar_t*g_Path=GetAppPathW(); 

int iF=wcslen(g_Path);
g_Path[iF]='\\'; g_Path[iF+1]=0;  wcscat(g_Path,L"Search_History.txt");


if(0)qTraceW(g_Path);
int ic=SaveHistory(hdlg, IDC_COMBO11, g_Path);    // 保存搜索历史记录  

g_Path[iF]=0;                       // 恢复 g_Path 记录的路径 


PostQuitMessage(0); 
SendMessage(GetMainWnd(), WM_QUIT,0,0);  // WM_DESTROY 不行 
// DeleteObject(g_hBrush);	
// DestroyWindow(GetParent(hdlg));   // 不行
}break;
  

case WM_DRAWITEM:{ 

DWORD dwStatus=0; 
if( hThread!=0L){ if( !GetExitCodeThread(hThread,&dwStatus) ) eInfo("GetExitCodeThread"); }

LPDRAWITEMSTRUCT lpdis= (LPDRAWITEMSTRUCT) lParam; 

if(lpdis->itemState & ODS_SELECTED){ DrawEdge(lpdis->hDC,&lpdis->rcItem,BDR_SUNKENINNER,BF_SOFT|BF_RECT);
DrawFocusRect(lpdis->hDC,&lpdis->rcItem); 
}else DrawEdge(lpdis->hDC,&lpdis->rcItem,BDR_RAISEDINNER,BF_SOFT|BF_RECT);

if(dwStatus==STILL_ACTIVE){ SetTextColor(lpdis->hDC,0xc0c0c0); 
DrawText(lpdis->hDC,"终止任务",8,&lpdis->rcItem,DT_CENTER|DT_VCENTER|DT_SINGLELINE); 
}else{ SetTextColor(lpdis->hDC,0xFF0000); // 0xc0c0c0
DrawText(lpdis->hDC,"  搜索  ",8,&lpdis->rcItem,DT_CENTER|DT_VCENTER|DT_SINGLELINE); 
}

return true; 
}break; 









case WM_PAINT:  break; 
case WM_ERASEBKGND:   break;   // PostMessage(hdlg,WM_DRAW,0,0)对反复重绘!  


case WM_SIZE:{  
// MoveCombo(hdlg);  

//PostMessage(hdlg,WM_DRAW,0,0);   // 以免窗口位置偶尔混乱?
//PostMessage(getWnd(),WM_DRAW,0,0);
}break;   // 安放用户窗口    // case DM_REPOSITION: //=0xF

//case WM_DRAW:  MoveCombo(hdlg);  break;  
 
 
// case WM_USER + 0x100: MessageBox(0, "for CDN_FILEOK", 0, 0); break;

case WM_NOTIFY:{  // Only For Explore Style!

LPOFNOTIFYW pno=(LPOFNOTIFYW)lParam;   
LPNMHDR pnh=&pno->hdr; 
LPOPENFILENAMEW op=pno->lpOFN;       
//switch(pnh->idFrom){case 0: break; case 1: break;} // 原来的打开按钮-0 //Ok!      	  	  
switch(pnh->code){


case CDN_SELCHANGE: {  // 搜索范围以 0x047c 当前显示为准. 是文件、文件夹或多个文件需要重新判断.

// InvalidateRect(hdlg,0,true);  // CDM_GETFILEPATH, CDM_GETFOLDERPATH ... 

HWND hp=GetParent(hdlg);  // "Edit",显示文件夹/路径;

wchar_t*p=g_File;  
SendMessageW(hp,CDM_GETFILEPATH,MAX_PATH,(LPARAM)p);

if( !( GetFileAttributesW(p)&FILE_ATTRIBUTE_DIRECTORY ) ){
wchar_t*q=wcsrchr(p,'.'); 
if(q && 0!=wcsnicmp(q, L".htm",4) ) break; 
}


#if CONTACT_LIST|01
 
HWND hDlg=GetMainDlg(); 

//HWND hItem =  //  GetDlgItem(hp, 0x047c);           // winxp 0x0480 ---- win7  0x047c 
// hItem=FindWindowEx(hItem,0,"ComboBox",0);        // GetWindow(hItem,GW_CHILD);      // 否则无法操作 ComboBox  参见"说明.txt"
// GetDlgItem(hDlg, IDC_COMBO2);                       // 直接操作 0x47C会导致严重问题 
SendDlgItemMessageW(hDlg, IDC_COMBO2, CB_INSERTSTRING,1,(long)p);     // 默认存放位置保持在0-条  
SendDlgItemMessageW(hDlg, IDC_COMBO2, CB_SETCURSEL,1,0); 

break;

// SendMessage(hItem, CB_RESETCONTENT,0,0);  
 
// HWND hList=FindWindowExW(hp,0,L"SHELLDLL_DefView",L"");   // hList=GetWindow(hList,GW_CHILD);    // 也可以  
HWND hList=FindWindowExW(hList,0,L"SysListView32",L"FolderView"); 
 
int ic=0;    // SendMessage(hList,LVM_GETSELECTEDCOUNT,0,0);
int id=-1;
  
// int ido=SendMessage(hList,LVM_GETHOTITEM, 0,0);  
 

#endif  // CONTACT_LIST


//SendMessageW(hp,CDM_GETFOLDERPATH,MAX_PATH*3,(LPARAM)p);


}break;



case CDN_FILEOK:{  // COMMDLG.H(243):#define CDN_FILEOK  (CDN_FIRST - 0x0005)  // 改用于"搜索"按钮.  

// wchar_t Path[256], File[256]; int ip=SendMessageW(GetParent(hdlg),CDM_GETFOLDERPATH,256,(LPARAM)Path); wcscat(Path,ptr->lpOFN->lpstrFile);  // 尾部不带'\\'

OFNOTIFYW*ptr=(OFNOTIFYW*)lParam; 
WCHAR*p=wcsrchr(ptr->lpOFN->lpstrFile, L'.');  
if(p){   

if (wcsnicmp(p, L".htm", 4) == 0) {

IE_open(ptr->lpOFN->lpstrFile); 

}  // if 

// ShellExecuteW(0,L"open",ptr->lpOFN->lpstrFile,0,0,SW_SHOW); 
}  // if(p) 


SetLastError(0); SetWindowLong(hdlg,DWL_MSGRESULT,(long)2); return true;  // 使用IDOK时必须立即返回!
}break;

default:break; //switch(pnh->code)
}                        

}break;  // case WM_NOTIFY



case WM_LBUTTONDOWN: break; 

case WM_RBUTTONDOWN:{
POINT p; GetCursorPos(&p);
UINT uFlag= TPM_CENTERALIGN|TPM_LEFTBUTTON|TPM_HORIZONTAL;    	
TrackPopupMenu(hMenu,uFlag,p.x,p.y,0,hdlg,0);
}break; 






case WM_COMMAND:  // =0x0111  //User Interface.  

switch(LOWORD(wParam)){

case IDC_BUTTON1:{  // 搜索 

DWORD dwStatus=0; 

if( hThread!=0L){ 
if( !GetExitCodeThread(hThread,&dwStatus) ) eInfo("GetExitCodeThread"); 
if(dwStatus==STILL_ACTIVE){
int iR=MessageBox(0,"是否停止当前搜索?","正在执行当前搜索",MB_YESNO); 
if(iR==IDYES) { TerminateThread(hThread,1);  CloseHandle(hThread); hThread=0;  assert("hThread==0"); }
break; 
}
}

// EnableMenuItem(hMenu,IDO_STOP,MF_BYCOMMAND|MF_GRAYED); // 禁止再次使用 IDO_STOP;Enable任务按钮.

int ic=0;  // OnSearchW(hdlg);  // ic+=OnSearch(hdlg);

// hThread=CreateThread(0,0,(LPTHREAD_START_ROUTINE)Search,hdlg,0,(DWORD*)&ic);
MoveWindow(GetParent(hdlg),0,0,1,1,1);   // 触发 WM_DRAWITEM, 很笨的方法！！！！！！


if(ic>0){
wchar_t szt[256]; 
SendDlgItemMessageW(hdlg, IDC_COMBO2, WM_GETTEXT, 256, (long)szt); 
int ir=SendDlgItemMessageW(hdlg, IDC_COMBO2, CB_FINDSTRING, -1, (long)szt); 
if(ir==CB_ERR) SendDlgItemMessageW(hdlg, IDC_COMBO2, CB_ADDSTRING, 0, (long)szt); 
}


}break;



case IDE_SORT:{

wchar_t Path[256], File[256]; 

int ip=SendMessageW(GetParent(hdlg),CDM_GETFOLDERPATH,256,(LPARAM)Path);  // 尾部不带'\\'
ip--;   // 包括尾部'\0' 

ip=SendDlgItemMessageW(hdlg, IDC_COMBO1, WM_GETTEXT,  256, (long)File);

if(ip<=0) break; 

wcscat(Path,L"\\");  wcscat(Path,File);   

// Sort(Path,1);  


}break; 

default:return FALSE; 
}break; // switch(wmId) //case WM_COMMAND




default:return false; //switch(uiMsg)   
}

return false;
}  // m_BrowseProcW 






#if BS_APPS|1

 
// 保存搜索历史记录  BrowseProc::WM_DESTROY  

int SaveHistory(HWND hdlg, UINT uID, LPCWSTR szFile){    // =0

HWND hItem = GetDlgItem(hdlg, uID);
if(!hItem) return 0;  

#if OPE_FILE|1

FILE*fp = _wfopen(szFile, L"wb");     // qTraceW(L"szFile=%s", szFile);

if (!fp) {  

wchar_t*g_Path=GetAppPathW();     // 不如使用  GetModuleFileName  

wchar_t*p= wcsstr(g_Path,L"\\Debug");  if(p) *p=0;  // 调试期间, 跳出  [Debug]

int iF=wcslen(g_Path);
g_Path[iF]='\\'; g_Path[iF+1]=0;  if(!szFile)wcscat(g_Path,L"History.txt"); else wcscat(g_Path,szFile); 
fp = _wfopen(g_Path, L"wb"); 

if(!fp) { qTraceW(L"%s\r\nnot found!\r\nszFile=%s", g_Path, szFile); return 0;  }

g_Path[iF]=0;  

} 

#endif    // OPE_FILE




// 写 Unioce 标志   -- fseek(fp,0,SEEK_SET);  // fwrite 不去除文件开头的数据?! 0xFEFF 
WORD w = 0xFEFF;          // _write( fileno(fp), &w, 2);  // Unicode text 标志是文件第一个WORD为 UNICODETEXTFLAG, 0xFEFF.
fwrite(&w,2,1,fp);        // also Ok 
  
int IC = SendMessage(hItem, CB_GETCOUNT, 0, 0); 

wchar_t szt[256];  
int ic=0; 
for(int i = 0; i < IC; i++){

SendMessageW(hItem, CB_GETLBTEXT, i, (long)szt); 

wchar_t*p = szt;  while(iswspace(*p))p++;
if(*p == 0 || *p == L'\r' || *p == L'\n') continue;

ic++; 
fwprintf(fp, L"%s\r\n", szt);
}    // for IC  

fclose(fp);

return ic;  
}




int LoadHistory(HWND hdlg, UINT uID, LPCWSTR szFile){

HWND hItem = GetDlgItem(hdlg, uID);

 
// wchar_t*g_Path=GetAppPathW();     // 不如使用  GetModuleFileName  
wchar_t g_Path[256]; GetModuleFileNameW(0, g_Path, 256);   wchar_t*p=wcsrchr(g_Path,'\\');  if(!p) p=wcsrchr(g_Path,'/');  if(p) *p=0; 


FILE*fp = _wfopen(szFile, L"rb"); 


if (!fp) {


p= wcsstr(g_Path,L"\\Debug");  if(p) *p=0;  // 调试期间, 跳出  [Debug]

int iF=wcslen(g_Path);
g_Path[iF]='\\'; g_Path[iF+1]=0;  if(!szFile)wcscat(g_Path,L"History.txt"); else wcscat(g_Path,szFile); 
fp = _wfopen(g_Path, L"rb"); 

if(!fp) { qTraceW(L"%s\r\nnot found!", g_Path); return 0;  }

g_Path[iF]=0;  

} 


if(!fp) { qTraceW(L"%s\r\nor\r\n%s not found!", szFile, g_Path); return 0;  }


WORD w=0;  fread(&w,2,1,fp); if(w!=0xFEFF) fseek(fp,0,SEEK_SET);  
// fseek(fp,2,SEEK_SET);

// qTrace("ftell=%d, sizeof(WORD)=%d", ftell(fp), sizeof(WORD)); 


wchar_t szt[258] = { 0 }, szq[258]={0};   // szq 用于检查重复列表项  



bool bRepeat=false;
int ir = 0, ic = 0;

p=0; 



while(!feof(fp)){

*szt=0; 
fgetws(szt,256, fp);   


p=szt;

#if CLIP_TEXT|1    //  可能包含 "\r\n" 

p=wcsstr(szt,L"\r\n");  if(p) *p=0;  
p=wcsrchr(szt,'\n');    if(p) *p=0; 
p=wcsrchr(szt,'\r');    if(p) *p=0; 

p = szt;

while(iswspace(*p))p++;

if(*p == 0 || *p == L'\r' || *p == L'\n') continue; 

// ic=wcslen(p);\
if(ic==6) qTraceW(L"%s(%d)\r\n%X[%c], %X[%c], %X[%c], %X[%c], %X[%c], %X[%c], %X[%c]", p, ic,  p[ic-6],p[ic-6],     p[ic-5],p[ic-5],     p[ic-4],p[ic-4],       \
p[ic-3],p[ic-3],      p[ic-2],p[ic-2],    p[ic-1],p[ic-1],    p[ic],p[ic]);

#endif   // CLIP_TEXT

// fwprintf(ft,L"[%s]\t", p);



#if USE_FINDSTRING|1   // 不要带  CBS_SORT style 

ir=SendMessageW(hItem, CB_FINDSTRINGEXACT, -1, (long)p); 
 
if(ir!=CB_ERR) continue; 


#else    // CB_FINDSTRINGEXACT 表现奇怪 ......

ic = SendMessageW(hItem, CB_GETCOUNT,0, 0); 

bRepeat=false;
for(int i=0; i<ic; i++){
ir=SendMessageW(hItem, CB_GETLBTEXT, i, (long)szq); 
qTraceW(L"p=[%s](%d), q=[%s](%d)", p, wcslen(p), szq, wcslen(szq)); 

ic=wcslen(p); 

bRepeat = (wcsnicmp(p,szq, ic)==0); 
if(bRepeat) break;

if(wcsstr(szq,p)){ 
int it=SendMessageW(hItem, CB_GETLBTEXTLEN, i, 0);
qTraceW(L"it=%d, ir=%d;   iq=%d, ip=%d, [%s]/[%s]", it, ir, wcslen(szq), wcslen(szt), szq, szt); 
}


}  // for 

if(bRepeat) continue;


#endif   // USE_FINDSTRING

 
    
// fwprintf(ft,L"\r\n"); 
SendMessageW(hItem, CB_ADDSTRING, 0, (long)p);
}  // while 


fclose(fp);

// fclose(ft);
// ShellExecute(0,"open","debug.log",0,0,SW_SHOW);  



return 1; 
}





 
HWND&GetBS(){static HWND g_hP; return g_hP; }   // setBS() ...   
// HWND&GetDlg(){static HWND g_hDlg; return g_hDlg; }    // see GetMainDlg     


// hWnd =Frame Window
void MoveBS(HWND hWnd){

int BR=12; 
float rs=0.5;  // 1-0.618;
RECT rc; GetClientRect(hWnd, &rc);
int x=BR,y=BR, w=rc.right-2*BR, h=rc.bottom-2*BR; 
 
y+=h/2;

HWND hp=GetBS();  // FindWindowEx(hWnd,0,"#32770",0);  
MoveWindow(hp, x, y, w*rs,h*rs, true); 
// MoveItems(hp); 
return;
}





// WM_SIZE. 放在 WM_INITDIALOG 中不行 

void MoveCombo(HWND hdlg){

HWND hp=GetParent(hdlg);   

HWND hItem = GetDlgItem(hp, 0x047c);  assert(hItem);  // by spy++,    ComboBox, 文件名(&N) 内容 
RECT rc; if(!GetWindowRect(hItem, &rc))qTrace("GetWindowRect"); 
// int w = rc.right - rc.left, h = rc.bottom - rc.top;

ShowWindow(hItem, SW_HIDE); 
 
hItem = GetDlgItem(hdlg, IDC_COMBO1); 
   // POINT pu =  {rc.left, rc.top};  ScreenToClient(hp,&pu);     \
POINT pb =  {rc.right, rc.bottom};  ScreenToClient(hp,&pb);  

MapWindowPoints(0L, hdlg, (POINT*)&rc, 2); 
// qTrace("[%d, %d,  %d, %d]-- [%d, %d,  %d, %d]", rc.left,rc.top, rc.right, rc.bottom, pu.x, pu.y,  pb.x, pb.y );


MoveWindow(hItem, rc.left,rc.top, rc.right-rc.left, 10*(rc.bottom-rc.top), true); 

}




void MoveItems(HWND hdlg) {

 

HWND hp=GetParent(hdlg);  
//HWND hdlg=FindWindowEx(hp,0L,"#32770",0);      // GetDlgItem(hp,IDD_DIALOG0) 不行 

 

int BX=4, BY=28;  
RECT re; GetClientRect(hp,&re); 
int W= re.right-re.left,  H=re.bottom-re.top; 

HWND hItem=GetDlgItem(hp,0x0470); if(!hItem) qTrace("0x0470 not found!");     // "All Files"                ComboBox         ID=470 
RECT rc;  GetWindowRect(hItem, &rc);
MapWindowPoints(0L, hdlg, (POINT*)&rc, 2); 
int x=rc.left, y=rc.top+BY, w= rc.right-rc.left,  h=rc.bottom-rc.top; 


hItem=GetDlgItem(hdlg,IDC_COMBO2);    
MoveWindow(hItem, x, y, w, h, true);    // x=rc.left, y=rc.top*0, y 必须指定为 0, 估计 hp 移动了 hdlg. 


hItem=GetDlgItem(hp,IDOK);       //  "打开" BUTTON   ID=1 
GetWindowRect(hItem, &rc);
MapWindowPoints(0L, hdlg, (POINT*)&rc, 2); 
x=rc.left, w= rc.right-rc.left,  h=rc.bottom-rc.top;
hItem=GetDlgItem(hdlg,IDC_BUTTON1);    
MoveWindow(hItem, x, y, w, h, true);    // x=rc.left, y=rc.top*0, y 必须指定为 0, 估计 hp 移动了 hdlg. 


hItem=GetDlgItem(hp,0x441);  if(!hItem) qTrace("0x0441 not found!");          //  "文件类型(&T):"            Static           ID=441  
GetWindowRect(hItem, &rc);
MapWindowPoints(0L, hdlg, (POINT*)&rc, 2); 
x=rc.left, w= rc.right-rc.left,  h=rc.bottom-rc.top;
hItem=GetDlgItem(hdlg,IDC_STATIC1);    
MoveWindow(hItem, x, y+4, w, h, true);    // x=rc.left, y=rc.top*0, y 必须指定为 0, 估计 hp 移动了 hdlg. 

return;  
}









#endif  // BS_APPS

