
#ifndef _FILEEX_H_
#define _FILEEX_H_    // #endif  // _FILES_H_ //

// �ṹ����FILES.CPP��ʵ��
#ifdef  _FILEEX_CPP_    // #endif  // _FILES_CPP_ //
#define FILEEX_EXTERN 
#else 
#define FILEEX_EXTERN extern 
#endif  // _FILES_CPP_ //

#include <stdio.h>
#include <io.h>
#include <fcntl.h>
//#include <sys/types.h>
#include <sys/stat.h>


typedef int ( * DIRENUMPROC)(const char*,LPVOID);       //  For EnumDirectory 
typedef int ( * DIRENUMPROCW)(const wchar_t*,LPVOID);   //  LPVOID ����, ����ǿ�, ���һ����Ա������ int, ���� FileAttribute.  



int EnumDirectory(const wchar_t* szPath,DIRENUMPROCW pDirProc,LPVOID pd);
int EnumDirectory(const char* szPath,DIRENUMPROC pDirProc,LPVOID pd);


// ���Ժ��� ...... 
int DirCount(const wchar_t*szPath, int* ipo);  
// int DirCount(const char*szPath, int* ipo);


int EnumFiles(const wchar_t* szPath, int pFProc(const wchar_t*, void*),LPVOID pd);
void t_EnumFiles(); 


// Ӧ�ó��� 
int SearchFile(char*szPath, const char* szFile);


int RunApp( const char*cmdLine, const char* szParam=0L, int iCmdShow=SW_SHOW ); 



BOOL GetFolder(LPTSTR szBuf,LPCTSTR szDefDir=0L,BOOL bFolderOnly=false); 


#endif  // _FILEEX_H_ //



