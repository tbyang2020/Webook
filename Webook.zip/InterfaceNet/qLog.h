

#pragma warning(disable:4996)

#define _CONST_RETURN  // strstr ... The macro _CONST_CORRECT_OVERLOADS is defined if both the const and non-const versions of these functions are available. If you require the non-const behavior for both C++ overloads, define the symbol _CONST_RETURN.













#define DBG_LOG 

#ifndef _QLOG_H_
#define _QLOG_H_    // #endif  // _QLOG_H_ //

// �ṹ���� QLOG.CPP ��ʵ��
#ifdef  _QLOG_CPP_    // #define _QLOG_CPP_ //
#define QLOG_EXTERN 
#else 
#define QLOG_EXTERN extern 
#endif  // _QLOG_CPP_ //

#include <Windows.h>

#include <assert.h>

#include <stdio.h>

#ifndef  _CONSOLE
#define _WINDOWS
#endif

 
// ��Ҫȫ�������滻 printf. VS2013���滻�ƺ������ֻ���ļ�. 
   

#define eInfo qTrace 



// qTrace �� sTrace ����� GetLastError ����Ϣ.
#define qTrace( ao, ... ) {    \
const char*qTrace_a = ao;  /*u82a(ao);*/    \
static char g_szDBG[1024];  DWORD er=GetLastError(); LPSTR psz=0;  \
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER, 0, er, 0,(LPTSTR)&psz, 0, 0);  \
	int qTrace_ip =0;  if(qTrace_a) qTrace_ip=sprintf(g_szDBG, qTrace_a, ##__VA_ARGS__);    \
	qTrace_ip += sprintf(g_szDBG+qTrace_ip,"\r\n[ERR %d] %s\r\n",er,psz);  \
	const char*p = strrchr(__FILE__, '\\');  if(!p)p = __FILE__;  \
	sprintf(g_szDBG + qTrace_ip, "\t[Line %d in File %s,%s]\r\n", __LINE__, p, __FUNCTION__);   \
	MessageBox(0,g_szDBG,qTrace_a,0);      \
LocalFree(psz);  \
}




// qTrace �� sTrace ����� GetLastError ����Ϣ.  // const wchar_t*p = wcsrchr(__FILE__, '\\'); 

#define qTraceW( ao, ... ) {      \
const wchar_t*qTrace_a = ao;  /*u82a(ao);*/    \
static wchar_t g_szDBG[1024];  DWORD er=GetLastError(); LPWSTR psz=0;  \
	FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER, 0, er, 0,(LPWSTR)&psz, 0, 0);    \
  int qTrace_ip =0;  if(qTrace_a) qTrace_ip=swprintf(g_szDBG, qTrace_a, ##__VA_ARGS__);    \
	qTrace_ip += swprintf(g_szDBG+qTrace_ip,L"\r\n[ERR %d] %s\r\n",er,psz);  \
	swprintf(g_szDBG + qTrace_ip, L"\t[ %S  Line %d in File %S]\r\n", __FUNCTION__, __LINE__, __FILE__ );   \
MessageBoxW(0,g_szDBG,qTrace_a,MB_OK);    LocalFree(psz);  \
}













int showMsg(const char *fmt, ...);  

DWORD qmsg(int id_edit, const char*fmt, ...);


//#define eInfo qTrace

 

// ��ȻӰ�� ShellExecute! ԭ��δ֪! "return" is danger! 

#if UNKNOWN_BUG|1

#define qTrace( a, ... ) { static char g_szDBG[1024];  g_szDBG[0]=0;   int ip=sprintf(g_szDBG, a, ##__VA_ARGS__ );    \
  int er = 0;WSAGetLastError(); LPTSTR psz;   \
  FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER, 0, er, 0, (LPTSTR)&psz, 0, 0);  \
  const char*dbg_ptr = strrchr(__FILE__, '\\');  if(!dbg_ptr)dbg_ptr = __FILE__;   \
  sprintf(g_szDBG + ip, "\t[ERR %d]%s\t[Line %d, Function %s,  in File %s]\r\n", er, psz, __LINE__, __FUNCTION__, dbg_ptr);   \
  MessageBox(0,g_szDBG,a,0);  /*showMsg("%s\t %s",a,g_szDBG);*/     \
/*return er;*/   \
}

#endif  // UNKNOWN_BUG // return is danger! 

 


#endif  // _QLOG_H_ //





