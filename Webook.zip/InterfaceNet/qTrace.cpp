







#define _QLOG_CPP_ //


#include <Windows.h>
#include <assert.h>
#include <stdio.h>

#include "qTrace.h"







//#if !defined(_CONSOLE) 

// _qLog, qdbg_log, ��¼/��ʾ log �ļ�.     
 
void _qLog(const char*fmt, ...) {    
 
const  char* szFile="qLog.txt";  //  = g_File;  // "tack.txt"; 
 



static FILE*g_fp=0;   

if(!fmt){ 

if(g_fp){

fclose(g_fp);  g_fp = 0L;     // �ر� qLog.txt �ļ�, ��ʾ������.  

HINSTANCE pid=ShellExecute(0, "open", szFile, 0, 0, SW_SHOW);    
if((int)pid<=32)  qTrace("ShellExecute"); 


#if DEL_FILE   // û��Ҫɾ���ļ� 


	  

#if WAIT_SCHEME|1  // �ȴ����� 1 


int ic = 0; while (!FindWindow("Notepad", "tack.txt - ���±�")) { Sleep(10); ic++; if (ic > 200)break; } // WaitForSingleObject(hinst, INFINITE);


#else


PROCESS_INFORMATION pi;
STARTUPINFO si;  // [in] 
ZeroMemory(&si, sizeof(si));
si.cb = sizeof si; // Only compulsory field

// si.dwFlags = STARTF_USESHOWWINDOW;  si.wShowWindow = SW_SHOW;
     
// "%windir%/system32/notepad.exe"   CreateProcess ������·��! cmdLine���������·��  
if ( !CreateProcess("c:/windows/system32/notepad.exe", (TCHAR*)" qdbg_log.txt", 0,0,0,0,0,0, &si, &pi) ) { eInfo("CreateProcess"); return; }
WaitForSingleObject(pi.hProcess, INFINITE);

TerminateProcess(pi.hProcess,0);   // ��������Ȼû���˳�?

CloseHandle(pi.hThread);
CloseHandle(pi.hProcess);
#endif  // WAIT_SCHEME

DeleteFile(szFile);  // �����ۼ� ... ����ɾ�������ļ���Ӱ�� ShellExecute 



#endif  // DEL_FILE



}  // if...else

return;      
} 	// if(!fmt)    
	

// ��¼������Ϣ 
if (!g_fp) g_fp = fopen(szFile, "wb");

// static char po[1024];   

va_list v; va_start(v, fmt); vfprintf(g_fp, fmt, v); va_end(v);

// static int ie=0; ie++;  fprintf(g_fp,"\r\nERR %d\t\t ", ie);
// fprintf(g_fp, "%s", po);   //  fprintf(g_fp,po) ����, ��Ϊ po �ڿ����и�ʽ�ַ���.
// fflush(g_fp);
 
}  // _qLog 























//#ifndef IDC_EDIT1
//#define IDC_EDIT1 0x011 
//#endif  // IDC_EDIT1


#include <tlhelp32.h>
//#include "res/resource.h"









extern CRITICAL_SECTION g_spinlock;  // in httpProxy.cpp  �����һʱ���ʼ��, in WinMain or WndProc 


#if M_GETWINDOW|0


DWORD GetMainThreadId(DWORD pId = 0){
 if(pId == 0) pId = GetCurrentProcessId();

 DWORD threadId = 0;
 THREADENTRY32 te32 = { sizeof(te32) };
 HANDLE threadSnap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
 if(Thread32First(threadSnap, &te32))
 {
  do
  {
   if( pId == te32.th32OwnerProcessID )
   {
    threadId = te32.th32ThreadID;
    break;
   }
  }while(Thread32Next(threadSnap, &te32));
 }
 return threadId;
}

BOOL CALLBACK eproc(HWND hwnd, LPARAM lParam){  if(hwnd) *(HWND*)lParam = hwnd; return hwnd==NULL; }




#endif  // M_GETWINDOW





// ����ر�־ "//id:16", ��ʾ id=16. IDC_EDIT1=0x010. Win32��������� printf  












