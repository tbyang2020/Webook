
#ifndef _BROWSE_H_
#define _BROWSE_H_    //#endif  // _BROWSE_H_ //

//�ṹ����ASTRONOMY.CPP��ʵ��
#ifdef  _BROWSE_CPP_    //#endif  // _BROWSE_CPP_ //
#define BROWSE_EXTERN 
#else 
#define BROWSE_EXTERN extern 
#endif  // _BROWSE_CPP_ //


HWND CreateBS(HWND hParent=0,  void*ps=0); 

bool Browse(LPCWSTR szDir=0);  // , LPCWSTR szFilter = 0





// BROWSE_EXTERN  HWND g_hdlg;    // =  getBS()
HWND&GetBS();    // setBS() ...   
// HWND&GetDlg();  // see GetMainDlg  





void MoveBS(HWND hWnd);    // hWnd =Frame Window

void MoveCombo(HWND hdlg);  // WM_SIZE. ���� WM_INITDIALOG �в���? 

void MoveItems(HWND hdlg); 

 






//// <not useed;
//Members from OPENFILENAMEW; 
typedef struct OFNSELECTION 
{
WORD nFileOffset; //Specifies the zero-based offset, in characters, from the beginning of the path to the file name in the string pointed to by lpstrFile. If the user selects more than one file, nFileOffset is the offset to the first file name. 
WORD* lpstrFile;  //If the OFN_ALLOWMULTISELECT flag is set and the user selects multiple files, the buffer contains the current directory followed by the file names of the selected files. For Explorer-style dialog boxes, the directory and file name strings are NULL separated, with an extra NULL character after the last file name. 
} *LPOFNSELECTION;

 
#ifdef  _BROWSE_CPP_    //#endif  // _BROWSE_CPP_ //

wchar_t szBrowse[MAX_PATH];


wchar_t szProgramDir[MAX_PATH]=L"D:\\DevStudio\\m_Projects\\VcProjects\\Games\\for_colobot\\Unite\\pseudo\\program";


#endif  // _BROWSE_CPP_ //









//���ö�дBuffer;
//BROWSE_EXTERN WORD szBuffer[MAX_PATH];
BROWSE_EXTERN wchar_t szText[MAX_PATH];

//���ö�Buffer, ��д;
BROWSE_EXTERN wchar_t szModule[MAX_PATH];
// BROWSE_EXTERN wchar_t szPath[MAX_PATH];



BROWSE_EXTERN OFNSELECTION OFNSelection;
//// not useed>;



BROWSE_EXTERN HMENU hMenu;


wchar_t* GetAppPathW();



UINT_PTR CALLBACK BrowseProc(HWND hdlg,UINT uiMsg,WPARAM wParam,LPARAM lParam); 



 
int SaveHistory(HWND hdlg, UINT uID, LPCWSTR szFile);  
int LoadHistory(HWND hdlg, UINT uID, LPCWSTR szFile);



  






 





#endif  // _BROWSE_H_ //