






#ifndef _DIALOG_H_
#define _DIALOG_H_    //#endif  // _DIALOG_H_ //

//�ṹ����INTERFACENET.CPP��ʵ��
#ifdef  _DIALOG_CPP_    //#endif  // _DIALOG_CPP_ //
#define DIALOG_EXTERN 
#else 
#define DIALOG_EXTERN extern 
#endif  // _DIALOG_CPP_ //

#include <Windows.h>
#include  "res/resource.h"



INT_PTR CALLBACK DialogProc(HWND hdlg,UINT uMsg, WPARAM wParam,LPARAM lParam);  


 

#endif  // _DIALOG_H_ //






