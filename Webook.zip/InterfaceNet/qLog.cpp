




#define MUTE_MSG  // printf ���� MessageBox 

// #define MUTE_ALL  // ����ʾ�κε�����Ϣ 


#define _QLOG_CPP_ //


#include <Windows.h>
#include <assert.h>
#include <stdio.h>

#include "qLog.h"
























//#ifndef IDC_EDIT1
//#define IDC_EDIT1 0x011 
//#endif  // IDC_EDIT1


#include <tlhelp32.h>
#include "res/resource.h"









extern CRITICAL_SECTION g_spinlock;  // in httpProxy.cpp  �����һʱ���ʼ��, in WinMain or WndProc 


#if M_GETWINDOW|1


DWORD GetMainThreadId(DWORD pId = 0){
 if(pId == 0) pId = GetCurrentProcessId();

 DWORD threadId = 0;
 THREADENTRY32 te32 = { sizeof(te32) };
 HANDLE threadSnap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
 if(Thread32First(threadSnap, &te32))
 {
  do
  {
   if( pId == te32.th32OwnerProcessID )
   {
    threadId = te32.th32ThreadID;
    break;
   }
  }while(Thread32Next(threadSnap, &te32));
 }
 return threadId;
}

BOOL CALLBACK eproc(HWND hwnd, LPARAM lParam){ MessageBox(0, "OK!", 0, 0);  if(hwnd) *(HWND*)lParam = hwnd; return hwnd==NULL; }




#endif  // M_GETWINDOW





// ����ر�־ "//id:16", ��ʾ id=16. IDC_EDIT1=0x010. Win32��������� printf  












