



#define _INTERFACENET_CPP_ 
#include "InterfaceNet.h"
// #include "Interact.h"
#include "Dialog.h"
#include "Browse.h"

#include "res/resource.h"

#include <commctrl.h>

#include <io.h>

#pragma comment(lib,"Ws2_32.lib")


// #define g_sck  ProxyServer 

//extern SOCKET g_sckpx;   //  Proxy Server 


#include "Interact.h"
#include "qTrace.h"




static HANDLE g_hThread=0; 



#include <shlobj.h>

 


#include "GetHttps.h"

#include "GetLink.h"


#include "RSP/RPS.h"
 

// #define printf( ao, ... ) { static char g_buf[1024]; sprintf(g_buf, ao, ##__VA_ARGS__);   SendDlgItemMessage(GetMainDlg(),IDC_EDIT1, EM_REPLACESEL, 0, (long)g_buf);  } 

#define WM_DRAW  (WM_USER+0x101)   // �Ա㲻�ػ� "MDICLIENT" �Ĵ��ڹ���  

  
HWND& GetMainWnd(){ static HWND hWnd; return hWnd; }
HWND& GetMainDlg(){ static HWND hDlg; return hDlg; }   // �� WM_INITDIALOG ��ָ�� hDlg  





#if FILE_MGR|1




// ȷ��App ����Ŀ¼. ��ʼ�� g_Path��a_Path. 
// ע��, ���ڷ���ֵ���� const WCHAR*, ���, ʹ�øú����õ��Ĳ�һ���� App Path !

wchar_t* GetAppPathW() {
    static wchar_t* g_path = 0;    // App path ʼ�ղ���.  


    if (!g_path) {
        g_path = new wchar_t[256];


#if USE_CMDLINE

        wchar_t* cw = GetCommandLineW();  // MessageBoxW(0,cw,L"GetCommandLineW",0);  // �ո�ָ�  name.exe  ��������  
        wchar_t* p = wcschr(cw, '\"'); if (p) p++; else p = cw; while (*p == 0x20)p++;



        wchar_t* q = wcsrchr(p, '\"'); if (q) *q = 0;
        q = wcsrchr(p, '\\'); if (q) *q = 0;
        q = wcsrchr(p, '\\'); if (q) *q = 0;

        wcscpy(g_path, p);  // ��¼��������Ŀ¼(��һ��), �Ա���ָ����ʱ�ļ���������¼�ȵ�    


#else

        GetModuleFileNameW(0, g_path, 256);
        wchar_t* p = wcsrchr(g_path, '\\'); if (p) *p = 0;

        p = wcsstr(g_path, L"\\Debug");  if (p) *p = 0;  // �����ڼ�, ����  [Debug]

#endif    //  USE_CMDLINE

    }    // if 0  


    return g_path;
}

// ����������ʷ��¼  BrowseProc::WM_DESTROY  

int SaveHistory(HWND hdlg, UINT uID, LPCWSTR szFile) {    // =0

    HWND hItem = GetDlgItem(hdlg, uID);
    if (!hItem) return 0;

#if OPE_FILE|1

    FILE* fp = _wfopen(szFile, L"wb");     // qTraceW(L"szFile=%s", szFile);

    if (!fp) {

        wchar_t* g_Path = GetAppPathW();     // ����ʹ��  GetModuleFileName  

        wchar_t* p = wcsstr(g_Path, L"\\Debug");  if (p) *p = 0;  // �����ڼ�, ����  [Debug]

        int iF = wcslen(g_Path);
        g_Path[iF] = '\\'; g_Path[iF + 1] = 0;  if (!szFile)wcscat(g_Path, L"History.txt"); else wcscat(g_Path, szFile);
        fp = _wfopen(g_Path, L"wb");

        if (!fp) { qTraceW(L"%s\r\nnot found!\r\nszFile=%s", g_Path, szFile); return 0; }

        g_Path[iF] = 0;

    }

#endif    // OPE_FILE




    // д Unioce ��־   -- fseek(fp,0,SEEK_SET);  // fwrite ��ȥ���ļ���ͷ������?! 0xFEFF 
    WORD w = 0xFEFF;          // _write( fileno(fp), &w, 2);  // Unicode text ��־���ļ���һ��WORDΪ UNICODETEXTFLAG, 0xFEFF.
    fwrite(&w, 2, 1, fp);        // also Ok 

    int IC = SendMessage(hItem, CB_GETCOUNT, 0, 0);

    wchar_t szt[256];
    int ic = 0;
    for (int i = 0; i < IC; i++) {

        SendMessageW(hItem, CB_GETLBTEXT, i, (long)szt);

        wchar_t* p = szt;  while (iswspace(*p))p++;
        if (*p == 0 || *p == L'\r' || *p == L'\n') continue;

        ic++;
        fwprintf(fp, L"%s\r\n", szt);
    }    // for IC  

    fclose(fp);

    return ic;
}

int LoadHistory(HWND hdlg, UINT uID, LPCWSTR szFile) {

    HWND hItem = GetDlgItem(hdlg, uID);


    // wchar_t*g_Path=GetAppPathW();     // ����ʹ��  GetModuleFileName  
    wchar_t g_Path[256]; GetModuleFileNameW(0, g_Path, 256);   wchar_t* p = wcsrchr(g_Path, '\\');  if (!p) p = wcsrchr(g_Path, '/');  if (p) *p = 0;


    FILE* fp = _wfopen(szFile, L"rb");


    if (!fp) {


        p = wcsstr(g_Path, L"\\Debug");  if (p) *p = 0;  // �����ڼ�, ����  [Debug]

        int iF = wcslen(g_Path);
        g_Path[iF] = '\\'; g_Path[iF + 1] = 0;  if (!szFile)wcscat(g_Path, L"History.txt"); else wcscat(g_Path, szFile);
        fp = _wfopen(g_Path, L"rb");

        if (!fp) { qTraceW(L"%s\r\nnot found!", g_Path); return 0; }

        g_Path[iF] = 0;

    }


    if (!fp) { qTraceW(L"%s\r\nor\r\n%s not found!", szFile, g_Path); return 0; }


    WORD w = 0;  fread(&w, 2, 1, fp); if (w != 0xFEFF) fseek(fp, 0, SEEK_SET);
    // fseek(fp,2,SEEK_SET);

    // qTrace("ftell=%d, sizeof(WORD)=%d", ftell(fp), sizeof(WORD)); 


    wchar_t szt[258] = { 0 }, szq[258] = { 0 };   // szq ���ڼ���ظ��б���  



    bool bRepeat = false;
    int ir = 0, ic = 0;

    p = 0;



    while (!feof(fp)) {

        *szt = 0;
        fgetws(szt, 256, fp);


        p = szt;

#if CLIP_TEXT|1    //  ���ܰ��� "\r\n" 

        p = wcsstr(szt, L"\r\n");  if (p) *p = 0;
        p = wcsrchr(szt, '\n');    if (p) *p = 0;
        p = wcsrchr(szt, '\r');    if (p) *p = 0;

        p = szt;

        while (iswspace(*p))p++;

        if (*p == 0 || *p == L'\r' || *p == L'\n') continue;

        // ic=wcslen(p);\
        if(ic==6) qTraceW(L"%s(%d)\r\n%X[%c], %X[%c], %X[%c], %X[%c], %X[%c], %X[%c], %X[%c]", p, ic,  p[ic-6],p[ic-6],     p[ic-5],p[ic-5],     p[ic-4],p[ic-4],       \
        p[ic-3],p[ic-3],      p[ic-2],p[ic-2],    p[ic-1],p[ic-1],    p[ic],p[ic]);

#endif   // CLIP_TEXT

// fwprintf(ft,L"[%s]\t", p);



#if USE_FINDSTRING|1   // ��Ҫ��  CBS_SORT style 

        ir = SendMessageW(hItem, CB_FINDSTRINGEXACT, -1, (long)p);

        if (ir != CB_ERR) continue;


#else    // CB_FINDSTRINGEXACT ������� ......

        ic = SendMessageW(hItem, CB_GETCOUNT, 0, 0);

        bRepeat = false;
        for (int i = 0; i < ic; i++) {
            ir = SendMessageW(hItem, CB_GETLBTEXT, i, (long)szq);
            qTraceW(L"p=[%s](%d), q=[%s](%d)", p, wcslen(p), szq, wcslen(szq));

            ic = wcslen(p);

            bRepeat = (wcsnicmp(p, szq, ic) == 0);
            if (bRepeat) break;

            if (wcsstr(szq, p)) {
                int it = SendMessageW(hItem, CB_GETLBTEXTLEN, i, 0);
                qTraceW(L"it=%d, ir=%d;   iq=%d, ip=%d, [%s]/[%s]", it, ir, wcslen(szq), wcslen(szt), szq, szt);
            }


        }  // for 

        if (bRepeat) continue;


#endif   // USE_FINDSTRING



        // fwprintf(ft,L"\r\n"); 
        SendMessageW(hItem, CB_ADDSTRING, 0, (long)p);
    }  // while 


    fclose(fp);

    // fclose(ft);
    // ShellExecute(0,"open","debug.log",0,0,SW_SHOW);  



    return 1;
}






//  ����������չ: ��������������ļ�/��  //  [2005��8��20�� 15ʱ26��]  

// BrowseCallbackProc For GetFolderEx �ص㴦�� BFFM_INITIALIZED ��Ϣ, ָ����ʼ·�� 

int CALLBACK BrowseProc(HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM lpData) {   // lpData --> BROWSEINFO::lParam

    switch (uMsg) {

    case BFFM_INITIALIZED: {  // SendMessage(hwnd,BFFM_ENABLEOK/BFFM_SETSELECTION/ BFFM_SETSTATUSTEXT ,...,...); 
        ::SendMessage(hwnd, BFFM_SETSTATUSTEXT, 0, (LPARAM)lpData);
        ::SendMessage(hwnd, BFFM_SETSELECTION, TRUE, (LPARAM)lpData);   //   (LPARAM)"C:\\WorkStation\\Work\\");   (LPARAM)"c:\\Permanent\\" 
    } break;


    case BFFM_SELCHANGED: {
        char szTmp[MAX_PATH];
        LPCITEMIDLIST pid = (LPCITEMIDLIST)(lParam);
        SHGetPathFromIDList(pid, szTmp); // wsprintf(szInfo,szTmp);
        ::SendMessage(hwnd, BFFM_SETSTATUSTEXT, 0, (LPARAM)szTmp);
        if (strstr(szTmp, ".wav"))  if (MessageBox(hwnd, "��ѡ����wav�ļ�.�Ƿ񲥷�?", NULL, MB_YESNO) == IDYES) ShellExecute(0, 0, szTmp, 0, 0, SW_SHOW);
    }break;

    case BFFM_VALIDATEFAILED: break;
    }
    return 0;
}



BOOL GetFolder(LPTSTR szBuf, LPCTSTR szDefDir, BOOL bFolderOnly) {


    if (!szBuf) return false;
    if (szDefDir == 0) szDefDir = "D:\\Tbyang20";   // ���� "D:/Tbyang20" ��ʽ 

    szBuf[0] = 0;
    ITEMIDLIST iDL;  LPITEMIDLIST piDL = &iDL;

    BROWSEINFO bi = { 0,0, 0L, "ָ���ļ���", BIF_EDITBOX, 0L,0,0, };  // |BIF_STATUSTEXT

    if (!bFolderOnly) bi.ulFlags |= BIF_BROWSEINCLUDEFILES;

    //bi.ulFlags |=  BIF_NEWDIALOGSTYLE ;   

    bi.lParam = (LPARAM)szDefDir;  bi.lpfn = BrowseProc;   // SendMessage(hwnd, BFFM_SETSELECTIONW,TRUE,(LPARAM)lpData),  ����Ĭ��Ŀ¼��������.  

    piDL = SHBrowseForFolder(&bi);

    if (piDL)SHGetPathFromIDList(piDL, szBuf);  //MessageBox(NULL,szBuf,"",0);
    else return false;

    return true;
}





UINT_PTR CALLBACK OFNHookProc(HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {

    switch (uMsg) {

    case WM_INITDIALOG: break;  // InitDialog.
    case WM_DESTROY: break;

    case WM_NOTIFY: {  // Only For Explore Style!

        LPOFNOTIFYW pno = (LPOFNOTIFYW)lParam;
        LPNMHDR pnh = &pno->hdr;
        LPOPENFILENAMEW op = pno->lpOFN;

        switch (pnh->code) {

        case CDN_SELCHANGE:    // CDN_SELCHANGE 
        case CDN_FILEOK: {   // COMMDLG.H(243):#define CDN_FILEOK  (CDN_FIRST - 0x0005)	
            char szF[256] = { 0 };
            HWND hp = GetParent(hdlg);  // "Edit",��ʾ�ļ���/·��;
            // ����CDN_FILEOK��0x0480�ĸ���, �Ա�����������ʾ��ѡ�ļ�[��]������·��.
            SendMessage(hp, CDM_GETFILEPATH, MAX_PATH, (LPARAM)szF);
            SendMessage(hp, 0x047C, WM_SETTEXT, (LPARAM)szF);
            SendDlgItemMessage(GetMainDlg(), IDC_EDIT1, WM_SETTEXT, 0, (LPARAM)szF);

            if (pnh->code == CDN_FILEOK) { SetLastError(0); SetWindowLong(hdlg, DWL_MSGRESULT, (long)1);  return TRUE; }  // ������������!

        }break;

        default:break; //switch(pnh->code)
        }

    }break;  // WM_NOTIFY.


    }  // switch(uMsg)

    return false;
}

// OPENFILENAME::nMaxFile, ���ڽ�ȡ ofn.lpstrFile=szFileName ����ѡ��ʱ��·�����ļ�

BOOL GetFileName(LPWSTR szFileName, HWND hWnd, BOOL bSave, LPCWSTR szFilter, LPCWSTR szInitial) { //=FALSE=NULL=NULL //UINT uFilterID,

    static wchar_t g_szFilter[MAX_PATH] = { 0 };
    if (szFilter) wcscpy(g_szFilter, szFilter);
    else swprintf(g_szFilter, L"All Files (*.*)|*.*|Web Files (*.html;*.htm)|*.html;*.htm|Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|Icon Files (*.ICO)|*.ICO|Bitmap Files (*.bmp)|*.bmp|");

    wchar_t* p = g_szFilter;  while (*p != 0) { if (*p == '|') *p = 0; p++; }  // �滻'|'Ϊ'\0';

    *szFileName = 0;
    OPENFILENAMEW ofn = { sizeof(OPENFILENAMEW), hWnd,0,   g_szFilter, 0L,0,0,
    szFileName, MAX_PATH,  0,0,   szInitial, };

    // if(!bSave) ofn.nMaxFile*= 100;    // ������ѡ  

    ofn.Flags = OFN_EXPLORER | OFN_ENABLESIZING;  // |OFN_ENABLEHOOK;  // |OFN_SHOWHELP  |OFN_SHAREAWARE---������򿪳�ͻ
    // ofn.lpfnHook =(LPOFNHOOKPROC)OFNHookProc; 

    BOOL bok = FALSE;
    if (bSave) {
        ofn.Flags |= OFN_OVERWRITEPROMPT;  // �����ļ��Ѿ����� 
        ofn.lpstrDefExt = 0;
        ofn.lpstrTitle = L"�����ļ�";
        bok = GetSaveFileNameW(&ofn);
    }
    else {
        //ofn.Flags|=OFN_ALLOWMULTISELECT;  // ������ѡ  
        ofn.Flags |= OFN_FILEMUSTEXIST | OFN_SHAREAWARE;
        ofn.lpstrTitle = L"���ļ�"; //szTitle;
        bok = GetOpenFileNameW(&ofn);
    }

    // if(bok){   // MessageBoxW(0,szFileEx, 0,0); // FileEx ר���ڽ���Ŀ¼��. 
    //// if(*szFileName==0) wcscpy(szFileName, szFileEx);    }  

    return bok;
}

BOOL GetFileName(LPTSTR szFileName, HWND hWnd, BOOL bSave, LPCTSTR szFilter, LPCTSTR szInitial) { //=FALSE=NULL=NULL //UINT uFilterID,

    static char g_szFilter[MAX_PATH] = { 0 };
    if (szFilter) strcpy(g_szFilter, szFilter);
    else sprintf(g_szFilter, "All Files (*.*)|*.*|Web Files (*.html;*.htm)|*.html;*.htm|Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|Icon Files (*.ICO)|*.ICO|Bitmap Files (*.bmp)|*.bmp|");

    char* p = g_szFilter;  while (*p != 0) { if (*p == '|') *p = 0; p++; }  // �滻'|'Ϊ'\0';

    *szFileName = 0;
    OPENFILENAME ofn = { sizeof(OPENFILENAMEW), hWnd,0,   g_szFilter, 0L,0,0,
    szFileName, MAX_PATH,  0,0,   szInitial, };

    // if(!bSave) ofn.nMaxFile*= 100;    // ������ѡ  

    ofn.Flags = OFN_EXPLORER | OFN_ENABLESIZING | OFN_ENABLEHOOK;  // |OFN_SHOWHELP |OFN_SHAREAWARE---������򿪳�ͻ
    ofn.lpfnHook = (LPOFNHOOKPROC)OFNHookProc;

    BOOL bok = FALSE;
    if (bSave) {
        ofn.Flags |= OFN_OVERWRITEPROMPT;  // �����ļ��Ѿ����� 
        ofn.lpstrDefExt = 0;
        ofn.lpstrTitle = "�����ļ�";
        bok = GetSaveFileName(&ofn);
    }
    else {
        //ofn.Flags|=OFN_ALLOWMULTISELECT;  // ������ѡ  
        ofn.Flags |= OFN_FILEMUSTEXIST | OFN_SHAREAWARE;
        ofn.lpstrTitle = "���ļ�"; //szTitle;
        bok = GetOpenFileName(&ofn);
    }

    // if(bok){   // MessageBoxW(0,szFileEx, 0,0); // FileEx ר���ڽ���Ŀ¼��. 
    //// if(*szFileName==0) wcscpy(szFileName, szFileEx);    }  

    return bok;
}



#endif    // FILE_MGR






INT_PTR CALLBACK  DialogProc(HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {


    static HANDLE hThread = 0;

    switch (uMsg) {

    case WM_INITDIALOG: {

        GetMainDlg() = hdlg;

        //InitializeCriticalSection(&g_spinlock); 
        // WSADATA wsa;   WSAStartup(MAKEWORD(2,2), &wsa);  


#if SHOW_HOSTNAME|1

        char szt[256];  if (0 == gethostname(szt, 256))   printf("\r\nStandard host name for the local machine:\t%s\r\n", szt);
        hostent* ip = gethostbyname(szt);  if (ip) printf("Corresponding host information:\t\t\t%s\r\n", inet_ntoa(*(in_addr*)ip->h_addr_list[0]));
        if (0)if (ip) SendDlgItemMessage(hdlg, IDC_COMBO1, CB_ADDSTRING, 0, (long)inet_ntoa(*(in_addr*)ip->h_addr_list[0]));     // qTrace("%X: %s", ((in_addr*)ht->h_addr_list[0])->S_un.S_addr,   inet_ntoa(*(in_addr*)ht->h_addr_list[0]));  // 0x 64 01  A8 C0 = 192.168.1.100

#endif  // SHOW_HOSTNAME 


        SendDlgItemMessage(hdlg, IDC_COMBO1, CB_INSERTSTRING, 0, (long)"Http://www.baidu.com");
        SendDlgItemMessage(hdlg, IDC_COMBO1, CB_ADDSTRING, 0, (long)"http://www.faithfreedom.org/Articles/Sira.htm");
        SendDlgItemMessage(hdlg, IDC_COMBO1, CB_ADDSTRING, 0, (long)"https://www.buyiju.com/zhouyi/");

        SendDlgItemMessage(hdlg, IDC_COMBO1, CB_SETCURSEL, 0, 0);



        char* szPath = new char[256];     GetModuleFileName(0, szPath, 256);    // Ĭ�ϴ��λ��  
        char* p = strrchr(szPath, '\\');
        if (!p) p = strrchr(szPath, '/');
        if (!p) p = strrchr(szPath, 0);
        if (p) *p = 0;

        strcat(szPath, "\\webPage.html");
        SendDlgItemMessage(hdlg, IDC_COMBO2, CB_INSERTSTRING, 0, (long)szPath);    //  ������0-��  
        SendDlgItemMessage(hdlg, IDC_COMBO2, CB_SETCURSEL, 0, 0);
        // SendDlgItemMessage(hdlg, IDC_EDIT1, WM_SETTEXT, 0,(long)"״̬"); 

        delete[] szPath;

        LoadHistory(hdlg, IDC_COMBO1, L"Web_History.txt");    // ������ʷ��¼ ...  

        // ���� popup �˵�, ���Ƴ�������á��˳��ȵ�. hPopMenu=LoadMenu((HINSTANCE)GetWindowLong(hWnd,GWL_HINSTANCE),(LPCTSTR)IDR_MENU1); 
        hPopMenu = LoadMenu(0, (LPCTSTR)IDR_MENU1);
        hPopMenu = GetSubMenu(hPopMenu, 0);


    }break;


case WM_CLOSE: {  if(0)MessageBox(0, "WM_CLOSE", 0, 0); EndDialog(hdlg,0); return false; }break;     // return false ����� SHBrowseForFolder !?  ԭ����Ĭ�Ϸ��� IDC_CANCELL ��Ϣ! 


    case WM_DESTROY: {  if(0)MessageBox(0, "WM_DESTROY", 0, 0);    // WM_CLOSE �ᴥ�� WM_DESTROY  

        wchar_t* g_Path = GetAppPathW();

        int iF = wcslen(g_Path);
        g_Path[iF] = '\\'; g_Path[iF + 1] = 0;  wcscat(g_Path, L"Web_History.txt");

        int ic = SaveHistory(hdlg, IDC_COMBO1, g_Path);    // ����������ʷ��¼  

        g_Path[iF] = 0;                       // �ָ� g_Path ��¼��·�� 

        PostQuitMessage(0);
    }break;   // �����˳�  


    case WM_SIZE: {   // break;  
        if (wParam != SIZE_RESTORED) break;
        int w = LOWORD(lParam), h = HIWORD(lParam); int B = 12, bw = 84, bh = 24;
        HWND hItem = GetDlgItem(hdlg, IDC_COMBO1);   MoveWindow(hItem, bw, B, w - 2 * bw - 2 * B, h, 1);
        hItem = GetDlgItem(hdlg, IDOK);         MoveWindow(hItem, w - bw - B, B, bw, bh, 1);
        hItem = GetDlgItem(hdlg, IDC_COMBO2);   MoveWindow(hItem, bw, 2 * B + bh, w - 2 * bw - 2 * B, h, 1);
        hItem = GetDlgItem(hdlg, IDCANCEL);     MoveWindow(hItem, w - bw - B, 2 * B + bh, bw, bh, 1);
        hItem = GetDlgItem(hdlg, IDC_EDIT1);    MoveWindow(hItem, B, 3 * B + 2 * bh, w - 2 * B, h - 2 * bh - 4 * B, 1);
    }break;

        // case WM_LBUTTONDOWN: 
    case WM_RBUTTONDOWN: {
        POINT pt; GetCursorPos(&pt);
        TPMPARAMS tpm = { sizeof(tpm), };
        tpm.rcExclude.left = 0, tpm.rcExclude.top = 0, tpm.rcExclude.right = 300, tpm.rcExclude.bottom = 300; //screen area not to overlap;      
        UINT uFlag = TPM_VCENTERALIGN | TPM_LEFTBUTTON | TPM_HORIZONTAL;

        TrackPopupMenuEx(hPopMenu, uFlag, pt.x, pt.y, hdlg, &tpm);
    }break;






    case WM_DRAWITEM: {

        DWORD dwStatus = 0;
        if (hThread != 0L) { if (!GetExitCodeThread(hThread, &dwStatus)) eInfo("GetExitCodeThread"); }

        if (wParam != IDOK) break;

#if USE_DIS |1  // ʹ��  (DRAWITEMSTRUCT*)lParam ������ʹ��  WM_REDRAW = WM_USER+0x102 ��ʱˢ�°�ť����

        LPDRAWITEMSTRUCT lpdis = (LPDRAWITEMSTRUCT)lParam;

        if (lpdis->CtlID != IDOK)break;

        if (lpdis->itemState & ODS_SELECTED) {
            DrawEdge(lpdis->hDC, &lpdis->rcItem, BDR_SUNKENINNER, BF_SOFT | BF_RECT);
            DrawFocusRect(lpdis->hDC, &lpdis->rcItem);
        }
        else DrawEdge(lpdis->hDC, &lpdis->rcItem, BDR_RAISEDINNER, BF_SOFT | BF_RECT);

        if (dwStatus == STILL_ACTIVE) {
            SetTextColor(lpdis->hDC, 0xc0c0c0);
            DrawText(lpdis->hDC, "��ֹ����", 8, &lpdis->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        }
        else {
            SetTextColor(lpdis->hDC, 0xFF0000); // 0xc0c0c0
            DrawText(lpdis->hDC, "  ����  ", 8, &lpdis->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        }

#else





#endif   // USE_DIS



        return true;
    }break;



    case WM_COMMAND: {
        WORD wId = LOWORD(wParam), wEvent = HIWORD(wParam);


        switch (wId) {

        case IDT_DELADDR:
        case IDT_DELDIR: {

            UINT id = IDC_COMBO1;
            if (wId == IDT_DELDIR)   id = IDC_COMBO2;

            HWND hItem = GetDlgItem(hdlg, id);

            int ic = SendMessage(hItem, CB_GETCURSEL, 0, 0);
            if (ic == CB_ERR) break;
            SendMessage(hItem, CB_DELETESTRING, ic, 0);

        }break;


        case IDT_HTTPS: break;


        case IDOK: {




#if CHECK_THREAD |1


            DWORD dwStatus = 0;

            if (hThread != 0L) {
                if (!GetExitCodeThread(hThread, &dwStatus)) qTrace("GetExitCodeThread");
                if (dwStatus == STILL_ACTIVE) {
                    int iR = MessageBox(0, "�Ƿ�ֹͣ��ǰ����?", "����ִ�е�ǰ����", MB_YESNO);
                    if (iR == IDYES) { TerminateThread(hThread, 1);  CloseHandle(hThread); hThread = 0; InvalidateRect(hdlg, 0, 1);  if (0)assert("hThread==0"); }
                    break;
                }
            }


#endif   // CHECK_THREAD




            static char* szURL = new char[256], * szFile = new char[256];

            SendDlgItemMessage(hdlg, IDC_COMBO1, WM_GETTEXT, 256, (long)szURL);     // Ŀ����ַ  
            SendDlgItemMessage(hdlg, IDC_COMBO2, WM_GETTEXT, 256, (long)szFile);    // ���Ŀ¼ -- Ҳ�������ļ���   






#if DIR_NAME|1

// ��   D:\Tbyang20\m_Projects\������\Https\Debug\webPage ��ʾ�½�Ŀ¼ [webPage], Ĭ���ļ���  ...\webPage.html  

// �ȸ��� URL ���� szFile: 
            int ir = 0;
            char* r = strrchr(szURL, '.');
            if (r && 0 == strnicmp(r, ".htm", 4)) {
                r = strrchr(szURL, '\\');
                if (!r) r = strrchr(szURL, '/');
                if (r) {
                    char* s = strrchr(szFile, '/');
                    if (!s) s = strrchr(szFile, '\\');
                    if (s) { strcpy(s, r); }
                }
            }


            r = strrchr(szFile, '.');
            if (r)*r = 0;

            if (-1 == access(szFile, 0)) { // �����ҳ������ļ���Ŀ¼��, ����ҳ����ͬ, ��Ĭ��Ϊ [dwnPage] 
                ir = MessageBox(0, szFile, "Ŀ¼������,�Ƿ񴴽�?", MB_YESNO);
                if (ir == IDYES)CreateDirectory(szFile, 0L);
                else break;
            }

            if (r) *r = '.'; else strcat(szFile, ".html");

#endif    // DIR_NAME 

            SendDlgItemMessage(hdlg, IDC_COMBO2, CB_INSERTSTRING, 1, (long)szFile);   // 0-����Ĭ��λ��  
            SendDlgItemMessage(hdlg, IDC_COMBO2, CB_SETCURSEL, 1, 0);

            printf("\r\n��ַ[%s]\r\n", szURL);
            printf("����[%s]\r\n\r\n", szFile);


            // ir=MessageBox(0,szFile, "���鱣��λ��.�Ƿ����?", MB_YESNO);   if(ir==IDNO)break;  

            static struct PARAM { const char* URL; const char* szHtm; bool bLoc; } *pa = new PARAM;
            pa->URL = szURL;  pa->szHtm = szFile;  pa->bLoc=true; 

#if CREATE_THREAD|1

            // EnableMenuItem(hMenu,IDO_STOP,MF_BYCOMMAND|MF_GRAYED);  // ��ֹ�ٴ�ʹ�� IDO_STOP  Enable ����ť.

            int ic = 0;
            // hThread=CreateThread(0,0,GetPage, pa,0,(DWORD*)&ic);


           hThread = CreateThread(0, 0, GetLink, pa, 0, (DWORD*)&ic);    // GetHttps
             //hThread = CreateThread(0, 0, GetHttps, pa, 0, (DWORD*)&ic);    // GetHttps

            InvalidateRect(hdlg, 0, 1);   
// MoveWindow(hdlg,0,0,1,1,1);   // ���� WM_DRAWITEM, �ܱ��ķ���������������



#else

            // GetPage(pa);     
            // GetHttps(pa);    // GetHttps(szURL, szFile);

            GetURI(szURL);

#endif   // CREATE_THREAD




            // qTrace(szFile); // *r = 0;  // szFile �ٴθı�ΪĿ¼��  

            // ��д��ҳ�ļ�, ͬʱ�� src= ���͵���Դ�����ͬ���ļ�����

            SendDlgItemMessage(hdlg, IDC_COMBO1, CB_ADDSTRING, 0, (long)szURL);


            // delete[] szURL, szFile;   // static ��Ҫ delete!   
        }break;   // IDOK 




        case IDCANCEL: {   // ת�����������λ��  
            char* szFile = new char[256];

            if (!GetFolder(szFile, "D:\\Tbyang20\\��Դ"))break;    // ���� "D:/Tbyang20" ��ʽ 

            SendDlgItemMessage(hdlg, IDC_COMBO2, CB_INSERTSTRING, 0, (long)szFile);
            SendDlgItemMessage(hdlg, IDC_COMBO2, CB_SETCURSEL, 0, 0);

            delete[] szFile;
        }break;




        case IDC_COMBO1: {
            if (HIWORD(wParam) != CBN_SELCHANGE)break;


#if DIR_NAME|1

            char szURL[256], szFile[256];   // ��   D:\Tbyang20\m_Projects\������\Https\Debug\webPage ��ʾ�½�Ŀ¼ [webPage], Ĭ���ļ���  ...\webPage.html  
            int ir = SendDlgItemMessage(hdlg, IDC_COMBO1, CB_GETCURSEL, 0, 0);
            SendDlgItemMessage(hdlg, IDC_COMBO1, CB_GETLBTEXT, ir, (long)szURL);     // Ŀ����ַ  -- ע�� WM_GETTEXT ���� 
            SendDlgItemMessage(hdlg, IDC_COMBO2, WM_GETTEXT, 256, (long)szFile);      // ���Ŀ¼ -- Ҳ�������ļ���   

            bool bHtm = false;
            // �ȸ��� URL ���� szFile: 
            char* r = strrchr(szURL, '.');
            if (r && 0 == strnicmp(r, ".htm", 4)) {
                bHtm = true;
                r = strrchr(szURL, '\\');
                if (!r) r = strrchr(szURL, '/');
                if (r) {
                    char* s = strrchr(szFile, '\\');
                    if (!s) s = strrchr(szFile, '/');
                    if (s) { strcpy(s, r); }
                }
            }


            r = strrchr(szFile, '.');
            if (r)*r = 0;

            if (-1 == access(szFile, 0)) { // �����ҳ������ļ���Ŀ¼��, ����ҳ����ͬ, ��Ĭ��Ϊ [dwnPage] 
                ir = MessageBox(0, szFile, "Ŀ¼������,�Ƿ񴴽�?", MB_YESNO);
                if (ir == IDYES)CreateDirectory(szFile, 0L);
            }

            if (r) *r = '.'; else strcat(szFile, ".html");

            // printf("\r\n��ַ[%s]\r\n", szURL);  printf("����[%s]\r\n\r\n", szFile);

            if (bHtm) {
                SendDlgItemMessage(hdlg, IDC_COMBO2, CB_INSERTSTRING, 1, (long)szFile);
                SendDlgItemMessage(hdlg, IDC_COMBO2, CB_SETCURSEL, 1, 0);
            }
            else {
                SendDlgItemMessage(hdlg, IDC_COMBO2, CB_SETCURSEL, 0, 0);
            }

#endif    // DIR_NAME 

        }break;






        default:break;
        }  // switch(wmId)

    } break; // WM_COMMAND

    default:break;  //switch (uMsg)
    }

    
return FALSE;
}



int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int) {
    WSADATA wsa;   WSAStartup(MAKEWORD(2, 2), &wsa);

    DialogBox(0, (LPCTSTR)IDD_DIALOG1, 0, DialogProc);

    WSACleanup();  // �ͷ�Windows Socket DLL�������Դ  
    return 0;

#if BUCK_UP






    // char sz[]="abcd";  char*p=strrchr(sz,0);  qTrace("p-sz=%d", p-sz);   return 0; 


    // dwnPage("http://www.faithfreedom.org/Articles/Sira.htm", "D:\\Tbyang20\\m_Projects\\������\\Https\\Debug\\dwnPage.html");   return 0;   



    //GetMainWindow() = CreateDialog(hInst, (LPCTSTR)IDD_DIALOG1, 0, DialogProc);  //  modeless 

    // DialogBox(hInst, (LPCTSTR)IDD_DIALOG1, 0, DialogProc); return 0; 



    // HWND hdlg=CreateBS();    

    // int w=GetSystemMetrics(SM_CXSCREEN),  h=GetSystemMetrics(SM_CYSCREEN);  
    // MoveWindow(hdlg, 100, 100, w, h, 1);  



    HWND hWnd = 0;

#if USE_WINDOW|1

    WNDCLASSEX wc = { sizeof(WNDCLASSEX),CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW,WndProc,0,0,hInst,0, 0, \
    (HBRUSH)(COLOR_WINDOW + 1), (LPCTSTR)IDR_MENU1,WND_CLASS,0 };
    wc.hIcon = LoadIcon(0, IDI_ASTERISK);
    wc.hCursor = LoadCursor(0, IDC_ARROW);  // lest it is shown slow

    RegisterClassEx(&wc);

    DWORD styEx = WS_EX_APPWINDOW;  //WS_EX_TOPMOST| WS_EX_CLIENTEDGE;
    DWORD sty = WS_VISIBLE | WS_OVERLAPPED | WS_SYSMENU | WS_SIZEBOX;  //  | WS_CAPTION   |WS_MAXIMIZEBOX|WS_MINIMIZEBOX;  // WS_THICKFRAME|
    sty |= WS_CLIPCHILDREN | WS_CLIPSIBLINGS;

    RECT re = { 0 }; // GetWindowRect(GetDesktopWindow(),&re); 
    int  w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

    float r = 0.85;  // 0.618; 

    int x = w / 2 - w * r / 2, y = 10;
    w *= r, h *= 0.9;   // re.right=g_iWidth; re.bottom=g_iHeight;  AdjustWindowRectEx(&re, sty, false, styEx);  // Adjust window rect so it gives us our desired client rect when we create the window

    hWnd = CreateWindowEx(styEx, WND_CLASS, "Globe", sty, x, y, w, h, 0, 0, hInst, 0);


#else


    hWnd = CreateMsgWnd();


#endif   // USE_WINDOW

    GetMainWnd() = hWnd;



    // ע���ȼ� Ctrl+P, Pause, Ctrl+Q, Exit; 
    ATOM key_CTRL_P, key_CTRL_Q;
    key_CTRL_P = GlobalAddAtom(TEXT("_Hotkey_CTRL_P"));
    key_CTRL_Q = GlobalAddAtom(TEXT("_Hotkey_CTRL_Q")); // If hWnd=0, WM_HOTKEY messages are posted to the message queue of the calling thread and must be processed in the message loop.   
    if (!RegisterHotKey(0, key_CTRL_P, MOD_CONTROL, 'P')) { if (0)eInfo("RegisterHotKey CTRL_P"); }
    if (!RegisterHotKey(0, key_CTRL_Q, MOD_CONTROL, 'Q')) { if (0)eInfo("RegisterHotKey CTRL_Q"); }


    // ��ѭ��. 
    MSG msg = { 0,0 };
    while (GetMessage(&msg, 0, 0, 0)) {
        if (msg.message == WM_QUIT) { MessageBox(0, "WM_QUIT", 0, 0); break; }
        if (msg.message == WM_HOTKEY) {
            if (HIWORD(msg.lParam) == 'Q' || HIWORD(msg.lParam) == 'P') { if (hWnd) DestroyWindow(hWnd);  break; }
            //\\if(HIWORD(msg.lParam)=='P'){ g_bPause=!g_bPause; continue; }  // if(IsWindowVisible(hThisWnd)) ShowWindow(g_hWnd,SW_HIDE);   else ShowWindow(g_hWnd,SW_SHOW); 
        }  // if(..) Ԥ���� WM_HOTKEY 

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }



    // �����˳�
    UnregisterHotKey(0, key_CTRL_Q); // ע���˳��ȼ� Ctrl+Q
    UnregisterHotKey(0, key_CTRL_P); // ɾ���ȼ� Ctrl+P

    UnregisterClass(WND_CLASS, hInst);



    WSACleanup();  // �ͷ�Windows Socket DLL�������Դ  
    return msg.wParam;



#endif  //  BUCK_UP


return 0;
}




#if BACKUP_MORE






#if CONSOLE_APPS|1


int CreateConsole() {

 
char app[128] = "c:\\Windows\\System32\\cmd.exe";

char cmd[1024] = "/k @echo ��������С��Ϸ. ";      // ��ʹ��"/k "����


FILE* fp = fopen("c:/tmp.bat", "wb");     if (!fp) { MessageBox(0, strerror(errno), "fopen c:/...", 0); return 0; }

fprintf(fp, "@echo ����RSP.\r\n");

fclose(fp);


sprintf(cmd, "/k @echo off & c:/tmp.bat & @echo on");  // ��ʹ��"/k "����



    // ��ָ�� dwCreationFlags = CREATE_NEW_CONSOLE, ��ʹ�� main ���� 

    STARTUPINFO si; memset(&si, 0, sizeof(si)); si.cb = sizeof(si);  PROCESS_INFORMATION pi;
    ////si.dwFlags=STARTF_USESHOWWINDOW;  si.wShowWindow=SW_SHOW;  //// Ignored unless dwFlags specifies STARTF_USESHOWWINDOW. 
 CreateProcess(app, cmd, 0L, 0L, false, 0, 0L, 0L, &si, &pi);

    // WaitForInputIdle(pi.hProcess,INFINITE);       // �ȴ�,ֱ���ӹ��̽��ܼ�������. ������, Ҳ��̫��. 
    // WaitForSingleObject(pi.hProcess,INFINITE);    // �ȴ�,ֱ���ӹ����˳�!  



// CloseHandle(pi.hThread);    CloseHandle(pi.hProcess);

Sleep(500);

printf("ok\n");  system("echo ok!");

DeleteFile("c:/tmp.bat");
return 1;
}





int main_w(){


if(! AllocConsole()) {  qTrace(""); return 0; };

#if USE_FREOPEN|1    // ����������ļ��� conout$, conin$, conerr$  

freopen("CONOUT$", "w", stdout);   // conout$  CONOUT$ ������,   $ ����  

freopen("conin$", "r", stdin);  
// freopen("conerr$", "w", stderr);




#else

HANDLE hOut=GetStdHandle(STD_OUTPUT_HANDLE);
WriteConsole(hOut,"Hello",5,0L,0);    


#endif    // 


 

 
printf("Hello world!");   // cout << "Hello world!" << endl;

    

main_Net();


Sleep(1000);

// freopen("CONOUT$", "w", stdout);    // �޻ָ�Ч�� 


fclose(stdout);     //  �Ա� FreeConsole �����ر� Console ����
fclose(stdin);

if(!FreeConsole()) qTrace("");   // һ������ freopen ��ʧȥЧ�� -- ԭ�������� fclose!   

return 0;
}







#endif    // CONSOLE_APPS








//  https://blog.csdn.net/qq_39529180/article/details/96973531


LRESULT CALLBACK WndProcMsg(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam){

switch (message) {

case WM_CREATE: break;
// case WM_DESTROY: if(1)qTrace("WM_DESTROY");DestroyWindow(hWnd); PostQuitMessage(0);  break; 
case WM_QUIT:  if(0)qTrace("WM_QUIT");PostQuitMessage(0); break; 

case WM_DEVICECHANGE: MessageBox(0, "WM_DEVICECHANGE", "Message", 0);    //USB�豸�����ʾ
default: return DefWindowProc(hWnd, message, wParam, lParam);
}
return 0;
}



HWND  CreateMsgWnd(){ 
WNDCLASSEX wc={sizeof(WNDCLASSEX),0, WndProcMsg,0,0, 0,0, 0, 0,0, WND_CLASS,0 };     
// wc.hInstance= GetModuleHandle(0); 
RegisterClassEx(&wc);   // Create a normal top-level window which can receive the broadcast messages.
HWND hWnd=CreateWindowEx(0, WND_CLASS, "Title", 0, 0, 0, 0, 0, HWND_MESSAGE, 0, 0, 0);
if(!hWnd) qTrace("CreateWindowEx");
return hWnd;  
}
 








LRESULT CALLBACK WndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam ){

static HANDLE hProcIE;  
static HWND   hBS;  

switch(msg){

case WM_CREATE:{ 

// InitializeCriticalSection(&g_spinlock); 

WSADATA wsa;   WSAStartup(MAKEWORD(2,2), &wsa);  

SetWindowText(hWnd," y = f(x) "); 






#if ADD_DIALOG|0

// g_hdlg = 
CreateDialog(GetModuleHandle(0), (LPCTSTR)IDD_DIALOG1,hWnd,DialogProc); 

//MoveWindow(hDialog,B,B, w/3,h, true); 

#endif  // ADD_DIALOG




#if ADD_EDIT|0


//HWND hEdit=  \
CreateWindowExW( 0, L"Edit",L"", WS_VISIBLE|WS_CHILD|WS_BORDER      \
  |WS_VSCROLL|WS_HSCROLL |WS_SIZEBOX |ES_AUTOHSCROLL|ES_AUTOVSCROLL  |ES_MULTILINE|ES_WANTRETURN,	 \
  B,B, w/3,h, hWnd,(HMENU)IDC_EDIT1,0,0); 

// EditProc=(WNDPROC)GetWindowLong(hEdit,GWL_WNDPROC); SetWindowLong(hEdit,GWL_WNDPROC,(long)InterceptProc); 

CreateWindowExW( 0, L"Edit",L"", WS_VISIBLE|WS_CHILD|WS_BORDER     \
  |WS_VSCROLL|WS_HSCROLL |WS_SIZEBOX |ES_AUTOHSCROLL|ES_AUTOVSCROLL  |ES_MULTILINE|ES_WANTRETURN,	 \
  2*B+w/3,B, w*2/3,h, hWnd,(HMENU)IDC_EDIT1,0,0); 

#endif  // ADD_EDIT




#if M_TOOLTIP|0

UINT uId=IDC_EDIT1;  // AddEdit(hWnd,0x010,0);
   
HWND hToolTip=CreateWindowExW(WS_EX_TOPMOST,TOOLTIPS_CLASSW,0,  \
                          TTS_NOPREFIX|TTS_ALWAYSTIP,0,0,0,0,  \
                          hWnd, 0,0,0);  // |TTM_RELAYEVENT;// | TTS_BALLOON,

//HWND hToolTip=CreateWindowEx(WS_EX_TOPMOST,TOOLTIPS_CLASS,0,  \
                          TTS_NOPREFIX|TTS_ALWAYSTIP,0,0,0,0,  \
                          hWnd, 0,0,0); 

TOOLINFO ti = { 0 }; ti.cbSize = sizeof(TOOLINFO);  
//TOOLINFOW ti = { 0 }; ti.cbSize = sizeof(TOOLINFOW);  
ti.hwnd=hWnd;   ti.uId = uId;
ti.uFlags = TTF_SUBCLASS | TTF_ABSOLUTE | TTF_TRANSPARENT | TTF_IDISHWND; //TTF_TRACK|;
ti.uId=(UINT)GetDlgItem(hWnd,uId); 
ti.lpszText="IDC_EDIT1"; 
//ti.lpszText=L"Work Space"; 

if(!SendMessage(hToolTip,TTM_ADDTOOL,0,(LPARAM)&ti)) MessageBox(0,"IDC_EDIT1",0,0);  
//if(!SendMessageW(hToolTip,TTM_ADDTOOLW,0,(LPARAM)&ti)) MessageBox(0,"TTM_ADDTOOLW",0,0);   // VS2013����Ī������.

uId = IDD_DIALOG1;  // ti.uId = uId;
ti.uId=(UINT)GetWindow(hWnd,GW_CHILD); //GetDlgItem(hWnd,uId); 
ti.lpszText="IDD_DIALOG1"; 
if(!SendMessage(hToolTip,TTM_ADDTOOL,0,(LPARAM)&ti)) MessageBox(0,"IDD_DIALOG1",0,0);  

#endif  // M_TOOLTIP 




RECT rc; GetClientRect(hWnd, &rc);  
int B=12; 
int w=rc.right, h=rc.bottom; 

#if EMBED_BS|0
{
hBS=CreateBS(hWnd,0L); 

// SetWindowPos( hBS,  HWND_TOP,    B, h/2+B,  w/2, h/2-B,   SWP_FRAMECHANGED ); 
// MoveWindow( hBS,  B, h/2+B,  w/2, h/2-B,   true); 

}
#endif    //  EMBED_BS 







#if EMBED_DIALOG|1
{
HWND hdlg= GetMainDlg() = CreateDialog(0, (LPCTSTR)IDD_DIALOG1, 0, DialogProc);  //  modeless 

//long sty=GetWindowLong(hdlg,GWL_STYLE);    \
sty|=WS_CHILD;                             \
sty &= ~(WS_CAPTION|WS_BORDER);            \
SetWindowLong(hdlg, GWL_STYLE, sty);

SetParent(hdlg, hWnd); 

int B=12, w = rc.right-2*B; int  h = rc.bottom-2*B; 
// SetWindowPos( hdlg,  HWND_TOP,    B, B,  w/2, h/2-B,   SWP_FRAMECHANGED ); 
MoveWindow( hdlg,  B, B,  w/2, h/2-B,   true); 
}
#endif   // EMBED_DIALOG




#if EMBED_IE|0
{


// "C:\\Program Files\\Internet Explorer\\iexplore.exe"

hProcIE= RunProcess("\\Internet Explorer\\iexplore.exe");   // ShellExecute(0,0,"iexplore",0,0,SW_SHOW);  if((int)ir<=32) qTrace("ir=%d", ir); 
// assert(hProcIE);    


HWND hIE=0;  int ic=0;
while(!hIE){ hIE=FindWindow("IEFrame",0);  Sleep(100); ic++; if(ic>50)break; }
// assert(hIE);  // qTrace("hIE=%X", hIE);

//long sty=GetWindowLong(hIE,GWL_STYLE);   \
sty|=WS_CHILD;                           \
sty &= ~(WS_CAPTION|WS_CAPTION);         \
SetWindowLong(hIE, GWL_STYLE, sty);
GetIE()=hIE;  

SetParent(hIE, hWnd); 

RECT rc; GetClientRect(hWnd, &rc);  int B=12, w = rc.right-2*B; int  h = rc.bottom-2*B; 
// SetWindowPos( hIE,  HWND_TOP,    w/2+B, B,  w/2, h,   SWP_FRAMECHANGED ); 
MoveWindow( hIE,  w/2+B, B,  w/2, h,  true); 
}
#endif   // EMBED_IE







}break; 





case WM_QUIT:
case WM_DESTROY: {
if(hProcIE) {  int ir=TerminateProcess(hProcIE,0); if(0)CloseHandle(hProcIE);  if(0)qTrace("hProcIE=%X, ir=%d", hProcIE, ir);  }  
// if(hBS) DestroyWindow(hBS);    // ����Ч�� --  �Լ����̻߳��Զ��ر� 

if(g_hThread!=0) SendMessage(hWnd, WM_COMMAND, MAKEWPARAM( IDC_STOP, 0 ), 0); 

WSACleanup();  // �ͷ�Windows Socket DLL�������Դ  
PostQuitMessage(0);  

}
break;

// case WM_PAINT: drawFunc(hWnd,tec); break; 

case WM_DRAW:{ MoveBS(hWnd); }break;




case WM_SIZE:{  
    
if(wParam != SIZE_RESTORED) break; 


PostMessage(hWnd,WM_DRAW,0,0); 

#if SIZE_EDIT|0

int B=10, w = LOWORD(lParam)-2*B, h = HIWORD(lParam)-2*B; 

HWND hCtrl= // GetDlgItem(hWnd, IDD_DIALOG1);   
GetWindow(hWnd, GW_CHILD);  
MoveWindow(hCtrl, B,B, w/2,h, true); 

hCtrl=GetDlgItem( hWnd,IDC_EDIT1); MoveWindow(hCtrl, 2*B+w/2,B, w/2,h, true); 

#endif  // SIZE_EDIT

return 0; 
}  break;  // WM_SIZE 





case WM_KEYDOWN:
if(wParam==VK_ESCAPE)DestroyWindow(hWnd); 
break;

case WM_COMMAND:{
switch(LOWORD(wParam)){

//case IDC_EXIT:  TerminateThread(g_hThread,0); closesocket(g_sckpx); DestroyWindow(hWnd);  break; 

case IDC_DOWNPAGE:{

	char szFile[256*2]; 

	if(!GetFileName(szFile,0,true))break;  

// MessageBox(0,szFile,0,0);

	char*p = strrchr(szFile, '\\');
	if (!p) break; 

char*r = strrchr(p+1, '.'); 
if (!r) strcat(szFile, ".html");  
r = strrchr(p+1, '.');  assert(r);

*r=0;
if (-1==access(szFile,0)){ CreateDirectory(szFile,0L);  }  // �����ҳ������ļ���Ŀ¼��, ����ҳ����ͬ
*r = '.';  // �ָ���ҳ�ļ��� 



//dwnPage("http://www.baidu.com", szFile);

// dwnPage("http://www.faithfreedom.org/Articles/Sira.htm", szFile);   // 

//rePage(szFile); 





//dwnURL("http://www.baidu.com", szFile); 

// *r = 0;  // szFile �ٴθı�ΪĿ¼��  

// ��д��ҳ�ļ�, ͬʱ�� src= ���͵���Դ�����ͬ���ļ�����









}break;






case IDC_TEST: { 


//getPage("http://www.faithfreedom.org/Articles/Sira.htm");  break;  // "http://www.baidu.com"


//dwnURL("https://www.paypal.com/images/x-click-but21.gif",  "a.gif");  
//dwnURL("http://www.faithfreedom.org/ffi/grey_px2.gif",  "b.gif");  


// dwnURL("http://www.faithfreedom.org/lcurv.gif",  "lcurv.gif");  


// t_ParseHost(); 

} break;


case IDT_RSP:{
// CreateConsole();  
main_w();

}break;





case IDC_CLEAR: SendDlgItemMessage(hWnd,IDC_EDIT1,WM_SETTEXT, 0,0); break; 
case IDC_CLS2: SendDlgItemMessage(hWnd,IDC_EDIT1,WM_SETTEXT, 0,0); break; 

case IDC_START: { 
DWORD dw; GetExitCodeThread(g_hThread,&dw); 
if( dw==STILL_ACTIVE ){ MessageBox(0,"�������Ѿ�����","����������",MB_OK); break; }

//int Port = LISTEN_PORT;   // 8080;  // 
//g_hThread=CreateThread( 0,0,(LPTHREAD_START_ROUTINE)Proxy,(LPVOID)Port,0,&dw); 
//if(!g_hThread) {eInfo("CreateThread, Proxy"); break; }

SendMessage(GetMainDlg(), WM_COMMAND, MAKELONG(IDOK,0),0); 


EnableMenuItem(GetMenu(hWnd),IDC_START,MF_GRAYED); 
EnableMenuItem(GetMenu(hWnd),IDC_STOP,MF_ENABLED); 
} break; 

case IDC_STOP: {  // MessageBox(0, "IDC_STOP", 0, 0); 

DWORD dw; GetExitCodeThread(g_hThread,&dw); 
if(!(dw==STILL_ACTIVE))  MessageBox(0,"�����߳��Ѿ���ֹ!","�رշ�����",MB_OK);  

//if(!TerminateThread(g_hThread,0) ){ eInfo("TerminateThread "); } // ExitThread(0) -- ��ֹ��ǰ�߳�  
//CloseHandle(g_hThread); g_hThread=0; 
//closesocket(g_sckpx); 

SendMessage(GetMainDlg(), WM_COMMAND, MAKELONG(IDOK,0),0); 

EnableMenuItem(GetMenu(hWnd),IDC_STOP,MF_GRAYED); 
EnableMenuItem(GetMenu(hWnd),IDC_START,MF_ENABLED); 
//SendDlgItemMessage(hWnd,IDC_EDIT1,WM_SETTEXT,0,0); 
} break; 

case IDC_GET:{  

//int Port = LISTEN_PORT; 
DWORD dw; 

//CreateThread( 0,0,(LPTHREAD_START_ROUTINE)getPagePX,(LPVOID)Port,0,&dw);

}break;


case IDH_IP:{

#if M_IDH_IP|1

  char*szt = new char[128], *szo = new char[256];
  gethostname(szt, 256); 

  hostent*ht=gethostbyname(szt);

  int ic=sprintf(szo, "Host name\t%s\r\n", szt, ht->h_name); 

  if(ht){

    char**p = ht->h_addr_list;

      ic+=sprintf(szo+ic, "host\t "); 

    while(*p){ 
      in_addr adr = *( (in_addr*)*p);				 

      ic+=sprintf(szo+ic, "\t%x\r\n\t\t[%x,%x.%x.%x]\r\n\t\t[%d,%d.%d.%d]", adr.S_un.S_addr,    
        adr.S_un.S_un_b.s_b1, adr.S_un.S_un_b.s_b2,adr.S_un.S_un_b.s_b3,adr.S_un.S_un_b.s_b4 ,
        adr.S_un.S_un_b.s_b1, adr.S_un.S_un_b.s_b2,adr.S_un.S_un_b.s_b3,adr.S_un.S_un_b.s_b4 );
      p++;     
    }

  }  // if(ht)

  MessageBox(0, szo, 0, MB_OK);

  delete[] szt, szo; 

#endif  // M_IDH_IP

}break;  // IDH_IP


}  // switch(LOWORD(wParam)) 





}break; // WM_COMMAND 

default: break; 
}

return DefWindowProc( hWnd, msg, wParam, lParam );  
}







#endif    // BACKUP_MORE



