





#ifdef __cplusplus
extern "C" {
#endif







#pragma warning(disable:4996)
#pragma warning( disable : 4100 4010)  // unreferenced formal parameter, single-line comment contains line-continuation character 
#pragma warning( disable : 4244 4305)  // Possible loss of data. 

 

 
#ifndef _QTRACE_H_
#define _QTRACE_H_    // #endif  // _QTRACE_H_ //

// �ṹ���� QLOG.CPP ��ʵ��
#ifdef  _QTRACE_CPP_    // #define _QTRACE_CPP_ //
#define QTRACE_EXTERN 
#else 
#define QTRACE_EXTERN extern 
#endif  // _QTRACE_CPP_ //

#include <Windows.h>

#include <assert.h>

#include <stdio.h>

#ifndef  _CONSOLE
#define _WINDOWS
#endif

 

//  _qLog ͨ�� g_File ָ���ļ���. 
// const char* g_File;  // inline  const char*& GetStr(){ static const char* str; return str; }   // ֻ�� c++ ��֧������?  
// inline void setstr(const char*ptr){ g_File=ptr; }




// ��Ҫȫ�������滻 printf. VS2013���滻�ƺ������ֻ���ļ�. 
  
#define Alert( ao, ... ) {  static char g_buf[1024];    \
int ip=sprintf(g_buf, ao, ##__VA_ARGS__);                \
const char*p = strrchr(__FILE__, '\\');  if(p)p++; else p = __FILE__;  \
ip+=sprintf(g_buf + ip, "\t[%s, Line %d in File %s]\t ", __FUNCTION__, __LINE__, p);   \
MessageBox(0,g_buf,ao,0);     }



// qTrace �� Alert ����� GetLastError ����Ϣ.
#define qTrace( ao, ... ) {  static char g_buf[1024];   int ip_ =sprintf(g_buf, ao, ##__VA_ARGS__);    \
const char*p = strrchr(__FILE__, '\\');  if(p)p++; else p = __FILE__;  \
ip_+=sprintf(g_buf + ip_, "\t[Line %d in File %s,%s]", __LINE__, p, __FUNCTION__);   \
DWORD er=WSAGetLastError(); LPSTR psz=0;    FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER, 0, er, 0,(LPTSTR)&psz, 0, 0);       \
ip_+=sprintf(g_buf + ip_,"\t  %s  \t", psz);        \
LocalFree(psz);   MessageBox(0,g_buf,ao,0);      }




#define    eInfo    qTrace 
#define    alert    Alert 






// ��Ҫ setlocale !  _wsetlocale(0, L"chs");  

#define qTraceW( ao, ... ) {  static WCHAR g_buf[1024];   int ip_=swprintf(g_buf, ao, ##__VA_ARGS__);    \
const char*p = strrchr(__FILE__, '\\');  if(p)p++; else p = __FILE__;  \
ip_+=swprintf(g_buf + ip_, L"\t[Line %d in File %S,%S]", __LINE__, p, __FUNCTION__);   \
DWORD er=GetLastError(); LPWSTR psz=0;    FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER, 0, er, 0, (LPWSTR)&psz, 0, 0);       \
ip_+=swprintf(g_buf + ip_, L"\t  %s  \t", psz);        \
LocalFree(psz);   MessageBoxW(0,g_buf,ao,0);      }













// qdbg_log, ��¼/��ʾ log �ļ�. qLog(): �ر�log�ļ�, ��ʾ������.  
void _qLog(const char*fmt, ...);


//  2021/9/17 ���� qLog �ر��ʺ���׷�ٵ�����!   //  ?ע��: #define�в�����ʹ�� va_list v; va_start(v, fmt); vsprintf(g_szDbgBuffer, fmt, v); va_end(v); 

// ��ʼ����������Ҫִ��һ�� Track(0).  static ��#define ����Ч!

#define Track(fmt,...) {  if(!fmt){ setstr("Track.txt");  _qLog(0); }else if( 0==strnicmp(g_File,"Track.txt",9) ){  const char*p=strrchr(__FILE__,'\\'); if(!p) p=__FILE__; else p++;    \
static char g_Log[1024]; 	*g_Log = 0;  sprintf(g_Log, fmt, ##__VA_ARGS__);   \
_qLog("\r\n%s \t %s  \t  %s Ln%d", g_Log,    __FUNCTION__, p, __LINE__);  }        \
}   // __TIME__ ֻ���ļ�����ʱ�� 






// Trace, �� Track ��ͬ, ����ʹ���ļ� Trace.txt, ����׷�ٺ���������!   ��ʼ����������Ҫִ��һ�� Trace(0).

#define Trace(fmt,...) { if(!fmt){ setstr("Trace.txt");  _qLog(0); }else if( 0==strnicmp(g_File,"Trace.txt",9) ){  const char*p=strrchr(__FILE__,'\\'); if(!p) p=__FILE__; else p++;    \
static char g_Log[1024]; 	*g_Log = 0;  sprintf(g_Log, fmt, ##__VA_ARGS__);   \
_qLog("\r\n%s \t %s  \t  %s Ln%d", g_Log,    __FUNCTION__, p, __LINE__);  }        \
}   // __TIME__ ֻ���ļ�����ʱ�� 


 



// Trail, �� Track ��ͬ, ����ʹ���ļ� Trail.txt, ����׷�ٺ���������!   ��ʼ����������Ҫִ��һ�� Trail(0).

#define Trail(fmt,...) { if(!fmt){ setstr("Trail.txt");  _qLog(0); }else if( 0==strnicmp(g_File,"Trail.txt",9) ){  const char*p=strrchr(__FILE__,'\\'); if(!p) p=__FILE__; else p++;    \
static char g_Log[1024]; 	*g_Log = 0;  sprintf(g_Log, fmt, ##__VA_ARGS__);   \
_qLog("\r\n%s \t %s  \t  %s Ln%d", g_Log,    __FUNCTION__, p, __LINE__);  }        \
}   // __TIME__ ֻ���ļ�����ʱ�� 


#define  track  Track  
#define  trace  Trace  
#define  trail  Trail  








 

 

 

// ��ȻӰ�� ShellExecute! ԭ��δ֪! "return" is danger! 

#if UNKNOWN_BUG|0

#define qTrace( a, ... ) { static char g_szDBG[1024];  g_szDBG[0]=0;   int ip=sprintf(g_szDBG, a, ##__VA_ARGS__ );    \
  int er = 0;WSAGetLastError(); LPTSTR psz;   \
  FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER, 0, er, 0, (LPTSTR)&psz, 0, 0);  \
  const char*dbg_ptr = strrchr(__FILE__, '\\');  if(!dbg_ptr)dbg_ptr = __FILE__;   \
  sprintf(g_szDBG + ip, "\t[ERR %d]%s\t[Line %d, Function %s,  in File %s]\r\n", er, psz, __LINE__, __FUNCTION__, dbg_ptr);   \
  MessageBox(0,g_szDBG,a,0);  /*showMsg("%s\t %s",a,g_szDBG);*/     \
/*return er;*/   \
}

#endif  // UNKNOWN_BUG // return is danger! 

 


#endif  // _QTRACE_H_ //







#ifdef __cplusplus
}
#endif


