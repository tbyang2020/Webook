﻿




#define   _INTERACT_CPP_  
#include    "Interact.h"
#include    "qTrace.h"


#include  <shlobj.h>
#include  <io.h>



#if IE_PLUG|1


#if WND_IDS
"IEFrame" #  "文件名 - Internet Explorer"    IE主窗口  
- "WorkerW" 0  "导航栏"              
-- "ReBarWindow32"  0000A006  ""  
--- "Address Band Root"  0000A205 "地址栏" 
---- "Edit"  0   "about:blank"
---- "ToolbarWindow32" 0  "地址组合控制"
---- "ToolbarWindow32" 0  "页面控制"   (0, 0)-(19, 24), 19x24  刷新按钮 →  

#endif    // WND_IDS


// 通过遥控IE地址栏打开网页 

void IE_open(const wchar_t* url){
HWND hIE=GetIE();  
HWND hBar=FindWnd(hIE,L"Address Band Root",0);  // 地址栏
HWND hButton=FindWnd(hBar,L"ToolbarWindow32",L"页面控制");  // 刷新按钮
// HWND hBar=FindWnd(hIE,L"AddressDisplay Control",0);  // 地址栏

HWND hEdit=FindWnd(hBar,L"Edit",0);  // 地址框  

SendMessageW(hEdit,WM_SETTEXT,0,(long)url);   
if(0)qTrace("0x%X, %X", hBar,  hButton);

 
Tap(hEdit);
// InvalidateRect(hBar,0,1); 
// SendMessage(hBar,WM_KEYDOWN,VK_RETURN,0);  
Tap(hButton, 0,0);




}

void IE_open(const char* url){
HWND hIE=GetIE();  
HWND hBar=FindWnd(hIE,L"Address Band Root",0);  // 地址栏
HWND hButton=FindWnd(hBar,L"ToolbarWindow32",L"页面控制");  // 刷新按钮
// HWND hBar=FindWnd(hIE,L"AddressDisplay Control",0);  // 地址栏

HWND hEdit=FindWnd(hBar,L"Edit",0);  // 地址框  

SendMessage(hEdit,WM_SETTEXT,0,(long)url);   
if(0)qTrace("0x%X, %X", hBar,  hButton);

 
Tap(hEdit);
// InvalidateRect(hBar,0,1); 
// SendMessage(hBar,WM_KEYDOWN,VK_RETURN,0);  
Tap(hButton, 0,0);




}






#endif    // IE_PLUG  





// 一般操作  

#if COMMON_OPS|1






// cmdLine, file name plus optional parameters. 注意, WinExec、CreateProcess 都有路径搜索功能. 

// 例如 cmdLine = "C:/Program Files (x86)/Internet Explorer/iexplore.exe  "
//      szParam=  " D:\\Worksite\\Vc_Studio\\m_Projects\\测试程序\\HTMLCalendar\\Calendar\\Calendar农历.htm"   // 必须前缀一个空格 


HANDLE RunProcess( const char*cmdLine, const char* szParam, int iCmdShow ){  // =0L,  =SW_SHOW


#if USE_EXECUTE|0    // 很难取得 pi.hProcess 

SHELLEXECUTEINFO  pi; memset(&pi,0,sizeof(pi));    // ={ sizeof(pi), SEE_MASK_NOCLOSEPROCESS|SEE_MASK_ASYNCOK, 0, "runas", cmdLine, szParam, 0, SW_SHOW,   0,   };  
pi.cbSize=sizeof(pi);   pi.fMask= 0;    pi.lpVerb="open";  
pi.lpFile=cmdLine;  pi.lpParameters=szParam;     


// pi.lpVerb="runas";     // pi.lpParameters="Administrator";      

if( !ShellExecuteEx(&pi) ) qTrace("错误"); 

if(pi.hProcess) WaitForSingleObject(pi.hProcess,INFINITE); 

return pi.hProcess; 


#else

//  if(!szParam)return  WinExec(cmdLine,iCmdShow);  // 不如直接调用. WinExec 在进程调用 GetMessage 时返回.


if(szParam && *szParam!=0x20){MessageBox(0,szParam,"必须前缀一个空格",0); return 0;}

STARTUPINFO sti={sizeof(sti),};  PROCESS_INFORMATION pi={0,}; memset(&pi,0,sizeof(pi));  
sti.dwFlags=STARTF_USESHOWWINDOW;
sti.wShowWindow= iCmdShow;     // SW_SHOW;
sti.lpTitle = 0L;              // 一般必须 =0L 

const char*App=cmdLine;  

#if FULL_PATH|1


if(0!=access(App,0)){

char szApp[256]="C:\\Program Files";   //  GetSystemDirectory(szDir,256);    // SHGetSpceialFolderLocation CSIDL_COMMON_PROGRAMS 
strcat(szApp,cmdLine);   // SHGetFolderPath(0,CSIDL_PROGRAM_FILES,0,0,szApp);        // 总是带 (x86) 
App=szApp; 
}   // 0!=...   


if( 0!=access(App,0) ) { MessageBox(0,App,"文件不存在!",0); return 0; }


#endif    // FULL_PATH  


//if(!CreateProcess(TEXT("C:\\Program Files (x86)\\HTML Help Workshop\\hhc.exe"), 0,      0L,0L,false,     0,   0L,0L,   &sti,   &pi)) show_error(TEXT("CreateProcess")); 
if( !CreateProcess(App,  (char*)szParam,    0L,0L, false,     0,   0L,       0,   &sti,   &pi)  ) MessageBox(0,"CreateProcess Error", 0,0); 

// WaitForSingleObject(pi.hProcess,INFINITE); 
WaitForInputIdle(pi.hProcess,INFINITE);   // 否则, FindWindow 要等待几百毫秒 
// Sleep(1000); 
// HWND hWnd=0; int it=0;  while(!hWnd){ hWnd=FindWindow("IEFrame",0L); Sleep(10); it+=10; printf("%d...\n",it); if(it>5000)break;  }   
// printf("\nhWnd=%X\n",hWnd);
return pi.hProcess; 


#endif   // USE_EXECUTE



}







// lParam 输入窗口类名、标题, 输出出口句柄  

BOOL CALLBACK FindWndProc(HWND hWnd, LPARAM lParam){ 
// DWORD cPId = *((DWORD*)lParam);  DWORD PId = 0; GetWindowThreadProcessId(hWnd, &PId); if(PId == cPId && GetParent(hWnd) == NULL) ... 
static wchar_t szClass[256], szTitle[256];    
GetClassNameW(hWnd,szClass,256); 
GetWindowTextW(hWnd,szTitle,256); 

// MessageBoxW(0,szClass,(wchar_t*)lParam,0); 
 
struct PARAM{wchar_t* p1; wchar_t* p2;} *ptr=(PARAM*)lParam;

if( wcscmp(szClass, ptr->p1) ==0 
// &&  wcscmp(szTitle, ptr->p2) ==0 
){  

if(0)qTrace("0x%X", hWnd);


if( !ptr->p2 ) {  *((HWND *)lParam) = hWnd;  return FALSE; }  // stop  
else if( wcscmp(szTitle, ptr->p2) ==0 ) {  *((HWND *)lParam) = hWnd;  return FALSE; }  // stop 

} 





return TRUE;        // continue 
} 
 

 
 


// 通过类名 ( 而非 ID) 取得子窗口句柄 
HWND FindWnd(HWND hParent,  const wchar_t* WndCls,  const wchar_t* Title ){  // =0L 
if(!WndCls) return 0L;  
if(!hParent) return FindWindowW(WndCls,Title);  

struct PARAM{wchar_t* p1; wchar_t* p2; }*ptr = new PARAM;   *ptr={0,0};  
ptr->p1=new wchar_t[256]; 
wcscpy(ptr->p1,WndCls);   
if(Title){ptr->p2=new wchar_t[256];  wcscpy(ptr->p2,Title);}

// wchar_t hWnd[256];  wcscpy(hWnd,WndCls); 
if(!EnumChildWindows(hParent,FindWndProc, (long)ptr)) return (HWND)*(long*)ptr;  
// char szt[128]; GetWindowText(hWnd, szt, 128);  MessageBox(0, szt, "t_GetMainWnd", MB_OK);  // 注意 EnumWindows 失败时也返回 false! 
}




// 模拟鼠标消息 -- 在窗口 hWnd 上的 (x,y) 位置单击鼠标  
void Tap(HWND hWnd, int x, int y){  // =0L, =0, =0,

if(hWnd){
RECT rc;  
GetWindowRect(hWnd,&rc);  
x+=rc.left;  y+=rc.top;  
}





#if USE_SENDINPUT|1

// HWND pZ = GetForegroundWindow();   SetForegroundWindow(hWnd);  





#if MORE_TEST|1

const double rx = 65535. / (GetSystemMetrics(SM_CXSCREEN) - 1),  ry = 65535. / (GetSystemMetrics(SM_CYSCREEN) - 1);

POINT po; GetCursorPos(&po);

double cx = po.x * rx,  cy = po.y * ry;
double nx = x * rx,  ny = y * ry;

    INPUT io={0};
    io.type = INPUT_MOUSE;

    io.mi.dx = (LONG)nx;    io.mi.dy = (LONG)ny;

    io.mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP;

    SendInput(1,&io,sizeof(INPUT));
 //   SendInput(1,&io,sizeof(INPUT));   // double click  

    io.mi.dx = (LONG)cx;    io.mi.dy = (LONG)cy;

    io.mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE;

    SendInput(1,&io,sizeof(INPUT));    // 返回  

#else    // --- more test




// SetCursorPos(x+3, y+3);   // 定位不如 mouse_event
INPUT io[2] = {0};
io[0].type = io[1].type=INPUT_MOUSE;

io[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;                 
io[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;                 

//io[0].mi.time=GetTickCount();  Sleep(10);  io[1].mi.time=GetTickCount()+10;
               
SendInput(sizeof(io)/sizeof(io[0]), io, sizeof(INPUT));

// SetForegroundWindow(pZ); // To activate previous window



#endif   










#else    // --- use mouse_event

SetCursorPos(x+3, y+3);

::mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);   // 鼠标左键按下
Sleep(10);    // 时间间隔
::mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);     // 鼠标左键弹起

#endif   // USE_SENDINPUT

return; 
}    // Tap






#endif    // COMMON_OPS
