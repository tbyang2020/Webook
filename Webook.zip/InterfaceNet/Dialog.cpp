



#define _DIALOG_CPP_ 
#include "Dialog.h"
#include "InterfaceNet.h"
//#include <Windows.h>

#include "res/resource.h"

#include <commctrl.h>

#include <io.h>

#pragma comment(lib,"Ws2_32.lib")


// #define g_sck  ProxyServer 

//extern SOCKET g_sckpx;   //  Proxy Server 


#include "Browse.h"
#include "qTrace.h"


CRITICAL_SECTION g_spinlock;   // ��һʱ���ʼ��. qLog.cpp ҲҪʹ��. 

static HANDLE g_hThread=0; 


//#include "../DownPage.h"
#include "FileEx.h"




#include "../GetPages.h"

#include "./Openssl/GetHttps.h"
 

#define printf( ao, ... ) { static char g_buf[1024]; sprintf(g_buf, ao, ##__VA_ARGS__);   SendDlgItemMessage(GetMainDlg(),IDC_EDIT1, EM_REPLACESEL, 0, (long)g_buf);  } 



#if DIALOG_UI|1

 
UINT_PTR CALLBACK OFNHookProc(HWND hdlg,UINT uMsg,WPARAM wParam,LPARAM lParam){

switch(uMsg){

case WM_INITDIALOG: break;  // InitDialog.
case WM_DESTROY: break;  

case WM_NOTIFY:{  // Only For Explore Style!

LPOFNOTIFYW pno=(LPOFNOTIFYW)lParam;   
LPNMHDR pnh=&pno->hdr; 
LPOPENFILENAMEW op=pno->lpOFN;       

switch(pnh->code){

case CDN_SELCHANGE:    // CDN_SELCHANGE 
case CDN_FILEOK:{   // COMMDLG.H(243):#define CDN_FILEOK  (CDN_FIRST - 0x0005)	
char szF[256]={0};
HWND hp=GetParent(hdlg);  // "Edit",��ʾ�ļ���/·��;
// ����CDN_FILEOK��0x0480�ĸ���, �Ա�����������ʾ��ѡ�ļ�[��]������·��.
SendMessage(hp,CDM_GETFILEPATH,MAX_PATH,(LPARAM)szF);
SendMessage(hp,0x047C,WM_SETTEXT,(LPARAM)szF);
SendDlgItemMessage(GetMainDlg(),IDC_EDIT1,WM_SETTEXT,0,(LPARAM)szF);

if(pnh->code==CDN_FILEOK) { SetLastError(0); SetWindowLong(hdlg,DWL_MSGRESULT,(long)1);  return TRUE; }  // ������������!

}break;
      
default:break; //switch(pnh->code)
}                        

}break;  // WM_NOTIFY.
  

}  // switch(uMsg)

return false;
}


// OPENFILENAME::nMaxFile, ���ڽ�ȡ ofn.lpstrFile=szFileName ����ѡ��ʱ��·�����ļ�

BOOL GetFileName(LPWSTR szFileName,HWND hWnd, BOOL bSave,LPCWSTR szFilter,LPCWSTR szInitial){ //=FALSE=NULL=NULL //UINT uFilterID,

static wchar_t g_szFilter[MAX_PATH]={0};   
if(szFilter) wcscpy(g_szFilter,szFilter); 
else swprintf(g_szFilter,L"All Files (*.*)|*.*|Web Files (*.html;*.htm)|*.html;*.htm|Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|Icon Files (*.ICO)|*.ICO|Bitmap Files (*.bmp)|*.bmp|");

wchar_t*p=g_szFilter;  while(*p!=0){ if(*p=='|') *p=0; p++; }  // �滻'|'Ϊ'\0';

*szFileName=0;
OPENFILENAMEW ofn={sizeof(OPENFILENAMEW), hWnd,0,   g_szFilter, 0L,0,0, 
szFileName, MAX_PATH,  0,0,   szInitial, };

// if(!bSave) ofn.nMaxFile*= 100;    // ������ѡ  

ofn.Flags=OFN_EXPLORER|OFN_ENABLESIZING ;  // |OFN_ENABLEHOOK;  // |OFN_SHOWHELP  |OFN_SHAREAWARE---������򿪳�ͻ
// ofn.lpfnHook =(LPOFNHOOKPROC)OFNHookProc; 

BOOL bok=FALSE;
if(bSave){
  ofn.Flags|=OFN_OVERWRITEPROMPT;  // �����ļ��Ѿ����� 
  ofn.lpstrDefExt =0;
  ofn.lpstrTitle =L"�����ļ�";
  bok=GetSaveFileNameW(&ofn);
}else{
  //ofn.Flags|=OFN_ALLOWMULTISELECT;  // ������ѡ  
  ofn.Flags|= OFN_FILEMUSTEXIST|OFN_SHAREAWARE;
  ofn.lpstrTitle =L"���ļ�"; //szTitle;
  bok=GetOpenFileNameW(&ofn); 
}

// if(bok){   // MessageBoxW(0,szFileEx, 0,0); // FileEx ר���ڽ���Ŀ¼��. 
//// if(*szFileName==0) wcscpy(szFileName, szFileEx);    }  

return bok;
}

BOOL GetFileName(LPTSTR szFileName,HWND hWnd, BOOL bSave,LPCTSTR szFilter,LPCTSTR szInitial){ //=FALSE=NULL=NULL //UINT uFilterID,

static char g_szFilter[MAX_PATH]={0};   
if(szFilter) strcpy(g_szFilter,szFilter); 
else sprintf(g_szFilter,"All Files (*.*)|*.*|Web Files (*.html;*.htm)|*.html;*.htm|Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|Icon Files (*.ICO)|*.ICO|Bitmap Files (*.bmp)|*.bmp|");

char*p=g_szFilter;  while(*p!=0){ if(*p=='|') *p=0; p++; }  // �滻'|'Ϊ'\0';

*szFileName=0;
OPENFILENAME ofn={sizeof(OPENFILENAMEW), hWnd,0,   g_szFilter, 0L,0,0, 
szFileName, MAX_PATH,  0,0,   szInitial, };

// if(!bSave) ofn.nMaxFile*= 100;    // ������ѡ  

ofn.Flags=OFN_EXPLORER|OFN_ENABLESIZING   |OFN_ENABLEHOOK ;  // |OFN_SHOWHELP |OFN_SHAREAWARE---������򿪳�ͻ
ofn.lpfnHook =(LPOFNHOOKPROC)OFNHookProc; 

BOOL bok=FALSE;
if(bSave){
  ofn.Flags|=OFN_OVERWRITEPROMPT;  // �����ļ��Ѿ����� 
  ofn.lpstrDefExt =0;
  ofn.lpstrTitle ="�����ļ�";
  bok=GetSaveFileName(&ofn);
}else{
  //ofn.Flags|=OFN_ALLOWMULTISELECT;  // ������ѡ  
  ofn.Flags|= OFN_FILEMUSTEXIST|OFN_SHAREAWARE;
  ofn.lpstrTitle ="���ļ�"; //szTitle;
  bok=GetOpenFileName(&ofn); 
}

// if(bok){   // MessageBoxW(0,szFileEx, 0,0); // FileEx ר���ڽ���Ŀ¼��. 
//// if(*szFileName==0) wcscpy(szFileName, szFileEx);    }  

return bok;
}



 


 

INT_PTR CALLBACK DialogProc(HWND hdlg,UINT uMsg, WPARAM wParam,LPARAM lParam){


static HANDLE hThread=0;
 
switch (uMsg){

case WM_INITDIALOG:{  

GetMainDlg() =  hdlg; 

//InitializeCriticalSection(&g_spinlock); 
// WSADATA wsa;   WSAStartup(MAKEWORD(2,2), &wsa);  


#if SHOW_HOSTNAME|1

char szt[256];  if (0==gethostname(szt, 256))   printf("\r\nStandard host name for the local machine:\t%s\r\n",  szt);   
hostent*ip = gethostbyname(szt);  if (ip) printf("Corresponding host information:\t\t\t%s\r\n",  inet_ntoa(*(in_addr*)ip->h_addr_list[0]) );  
if(0)if(ip) SendDlgItemMessage(hdlg, IDC_COMBO1, CB_ADDSTRING, 0, (long)inet_ntoa(*(in_addr*)ip->h_addr_list[0])  );     // qTrace("%X: %s", ((in_addr*)ht->h_addr_list[0])->S_un.S_addr,   inet_ntoa(*(in_addr*)ht->h_addr_list[0]));  // 0x 64 01  A8 C0 = 192.168.1.100
 
#endif  // SHOW_HOSTNAME 


SendDlgItemMessage(hdlg, IDC_COMBO1, CB_INSERTSTRING, 0, (long)"Http://www.baidu.com");
SendDlgItemMessage(hdlg, IDC_COMBO1, CB_ADDSTRING, 0, (long)"http://www.faithfreedom.org/Articles/Sira.htm");
SendDlgItemMessage(hdlg, IDC_COMBO1, CB_ADDSTRING, 0, (long)"https://www.buyiju.com/zhouyi/");

SendDlgItemMessage(hdlg, IDC_COMBO1, CB_SETCURSEL, 0, 0);



char * szPath = new char[256];     GetModuleFileName(0,szPath,256);    // Ĭ�ϴ��λ��  
char*p = strrchr(szPath, '\\');  
if (!p) p = strrchr(szPath, '/'); 
if (!p) p = strrchr(szPath,0); 
if (p) *p=0; 

strcat(szPath, "\\webPage.html");
SendDlgItemMessage(hdlg, IDC_COMBO2, CB_INSERTSTRING, 0,(long)szPath);    //  ������0-��  
SendDlgItemMessage(hdlg, IDC_COMBO2, CB_SETCURSEL, 0,0); 
// SendDlgItemMessage(hdlg, IDC_EDIT1, WM_SETTEXT, 0,(long)"״̬"); 

delete[] szPath; 

LoadHistory(hdlg, IDC_COMBO1,L"Web_History.txt");    // ������ʷ��¼ ...  

// ���� popup �˵�, ���Ƴ�������á��˳��ȵ�. hPopMenu=LoadMenu((HINSTANCE)GetWindowLong(hWnd,GWL_HINSTANCE),(LPCTSTR)IDR_MENU1); 
hPopMenu=LoadMenu(0,(LPCTSTR)IDR_MENU1);  
hPopMenu=GetSubMenu(hPopMenu,0);


}break;  

case WM_CLOSE:{  MessageBox(0,"WM_CLOSE",0,0);  }break; 

case WM_DESTROY:{  MessageBox(0,"WM_DESTROY",0,0);

wchar_t*g_Path=GetAppPathW(); 

int iF=wcslen(g_Path);
g_Path[iF]='\\'; g_Path[iF+1]=0;  wcscat(g_Path,L"Web_History.txt");

int ic=SaveHistory(hdlg, IDC_COMBO1, g_Path);    // ����������ʷ��¼  

g_Path[iF]=0;                       // �ָ� g_Path ��¼��·�� 

PostQuitMessage(0); 
}break;   // �����˳�  


case WM_SIZE:{   // break;  
if(wParam!=SIZE_RESTORED) break; 
int w=LOWORD(lParam), h=HIWORD(lParam); int B=12, bw=84, bh=24;   
HWND hItem=GetDlgItem(hdlg,IDC_COMBO1);   MoveWindow(hItem, bw,       B,         w-2*bw-2*B,  h,          1);  
     hItem=GetDlgItem(hdlg,IDOK);         MoveWindow(hItem, w-bw-B,   B,         bw,          bh,         1); 
     hItem=GetDlgItem(hdlg,IDC_COMBO2);   MoveWindow(hItem, bw,       2*B+bh,    w-2*bw-2*B,  h,          1); 
     hItem=GetDlgItem(hdlg,IDCANCEL);     MoveWindow(hItem, w-bw-B,   2*B+bh,    bw,          bh,         1); 
     hItem=GetDlgItem(hdlg,IDC_EDIT1);    MoveWindow(hItem, B,        3*B+2*bh,  w-2*B,       h-2*bh-4*B, 1); 
}break;

// case WM_LBUTTONDOWN: 
case WM_RBUTTONDOWN:{ 
POINT pt; GetCursorPos(&pt);  
TPMPARAMS tpm={sizeof(tpm),}; 
tpm.rcExclude.left=0,tpm.rcExclude.top=0,tpm.rcExclude.right=300,tpm.rcExclude.bottom=300; //screen area not to overlap;      
UINT uFlag=TPM_VCENTERALIGN|TPM_LEFTBUTTON|TPM_HORIZONTAL; 

TrackPopupMenuEx(hPopMenu,uFlag,pt.x,pt.y,hdlg,&tpm);
}break; 


 



case WM_DRAWITEM:{ 

DWORD dwStatus=0; 
if( hThread!=0L){ if( !GetExitCodeThread(hThread,&dwStatus) ) eInfo("GetExitCodeThread"); }

if(wParam!=IDOK) break; 

#if USE_DIS |1  // ʹ��  (DRAWITEMSTRUCT*)lParam ������ʹ��  WM_REDRAW = WM_USER+0x102 ��ʱˢ�°�ť����

LPDRAWITEMSTRUCT lpdis= (LPDRAWITEMSTRUCT) lParam; 

if(lpdis->CtlID!=IDOK)break; 

if(lpdis->itemState & ODS_SELECTED){ DrawEdge(lpdis->hDC,&lpdis->rcItem,BDR_SUNKENINNER,BF_SOFT|BF_RECT);
DrawFocusRect(lpdis->hDC,&lpdis->rcItem); 
}else DrawEdge(lpdis->hDC,&lpdis->rcItem,BDR_RAISEDINNER,BF_SOFT|BF_RECT);

if(dwStatus==STILL_ACTIVE){ SetTextColor(lpdis->hDC,0xc0c0c0); 
DrawText(lpdis->hDC,"��ֹ����",8,&lpdis->rcItem,DT_CENTER|DT_VCENTER|DT_SINGLELINE); 
}else{ SetTextColor(lpdis->hDC,0xFF0000); // 0xc0c0c0
DrawText(lpdis->hDC,"  ����  ",8,&lpdis->rcItem,DT_CENTER|DT_VCENTER|DT_SINGLELINE); 
}

#else





#endif   // USE_DIS



return true; 
}break; 



case WM_COMMAND:{
WORD wId=LOWORD(wParam), wEvent=HIWORD(wParam); 


switch(wId){  
  
case IDT_DELADDR:
case IDT_DELDIR:{ 

UINT id=IDC_COMBO1;
if(wId==IDT_DELDIR)   id=IDC_COMBO2;

HWND hItem=GetDlgItem(hdlg, id);

int ic=SendMessage(hItem,CB_GETCURSEL,0,0);  
if(ic==CB_ERR) break; 
SendMessage(hItem,CB_DELETESTRING,ic,0);
  
}break; 


case IDT_HTTPS: break;  


case IDOK:{ 




#if CHECK_THREAD |1


DWORD dwStatus=0; 

if( hThread!=0L){ 
if( !GetExitCodeThread(hThread,&dwStatus) ) qTrace("GetExitCodeThread"); 
if(dwStatus==STILL_ACTIVE){
int iR=MessageBox(0,"�Ƿ�ֹͣ��ǰ����?","����ִ�е�ǰ����",MB_YESNO); 
if(iR==IDYES) { TerminateThread(hThread,1);  CloseHandle(hThread); hThread=0; InvalidateRect(hdlg,0,1);  if(0)assert("hThread==0"); }
break; 
}
}

 
#endif   // CHECK_THREAD




static char* szURL=new char[256], * szFile=new char[256]; 

SendDlgItemMessage(hdlg, IDC_COMBO1, WM_GETTEXT, 256,(long)szURL);     // Ŀ����ַ  
SendDlgItemMessage(hdlg, IDC_COMBO2, WM_GETTEXT, 256,(long)szFile);    // ���Ŀ¼ -- Ҳ�������ļ���   






#if DIR_NAME|1

// ��   D:\Tbyang20\m_Projects\������\Https\Debug\webPage ��ʾ�½�Ŀ¼ [webPage], Ĭ���ļ���  ...\webPage.html  

// �ȸ��� URL ���� szFile: 
int ir=0;  
char*r=strrchr(szURL,'.');  
if(r && 0==strnicmp(r,".htm",4) ) {
r=strrchr(szURL,'\\');
if(!r) r=strrchr(szURL,'/');
if(r){
char*s=strrchr(szFile,'/');   
if(!s) s=strrchr(szFile,'\\'); 
if(s){ strcpy(s, r);} 
}}


r = strrchr(szFile, '.'); 
if(r)*r=0; 

if (-1==access(szFile,0)){ // �����ҳ������ļ���Ŀ¼��, ����ҳ����ͬ, ��Ĭ��Ϊ [dwnPage] 
ir=MessageBox(0,szFile, "Ŀ¼������,�Ƿ񴴽�?", MB_YESNO);
if(ir==IDYES)CreateDirectory(szFile,0L); 
else break;  
} 

if(r) *r='.'; else strcat(szFile,".html");

#endif    // DIR_NAME 

SendDlgItemMessage(hdlg, IDC_COMBO2,CB_INSERTSTRING,1,(long)szFile);   // 0-����Ĭ��λ��  
SendDlgItemMessage(hdlg, IDC_COMBO2,CB_SETCURSEL,1,0);    

printf("\r\n��ַ[%s]\r\n", szURL);
printf("����[%s]\r\n\r\n", szFile);


// ir=MessageBox(0,szFile, "���鱣��λ��.�Ƿ����?", MB_YESNO);   if(ir==IDNO)break;  

static struct PARAM{const char*URL; const char*szHtm;} *pa=new PARAM;
pa->URL=szURL;  pa->szHtm=szFile; 

#if CREATE_THREAD|1

// EnableMenuItem(hMenu,IDO_STOP,MF_BYCOMMAND|MF_GRAYED);  // ��ֹ�ٴ�ʹ�� IDO_STOP  Enable ����ť.

alert("Here!");
int ic=0; 
// hThread=CreateThread(0,0,GetPage, pa,0,(DWORD*)&ic);
hThread=CreateThread(0,0,GetHttps, pa,0,(DWORD*)&ic);
InvalidateRect(hdlg,0,1);   // MoveWindow(GetParent(hdlg),0,0,1,1,1);   // ���� WM_DRAWITEM, �ܱ��ķ���������������



#else

// GetPage(pa);     
// GetHttps(pa);    // GetHttps(szURL, szFile);

GetURI(szURL);  

#endif   // CREATE_THREAD




// qTrace(szFile); // *r = 0;  // szFile �ٴθı�ΪĿ¼��  

// ��д��ҳ�ļ�, ͬʱ�� src= ���͵���Դ�����ͬ���ļ�����

SendDlgItemMessage(hdlg,IDC_COMBO1, CB_ADDSTRING,0,(long)szURL);


// delete[] szURL, szFile;   // static ��Ҫ delete!   
}break;   // IDOK 
  
case IDC_COMBO1:{
if(HIWORD(wParam)!=CBN_SELCHANGE)break;


#if DIR_NAME|1

char szURL[256],  szFile[256];   // ��   D:\Tbyang20\m_Projects\������\Https\Debug\webPage ��ʾ�½�Ŀ¼ [webPage], Ĭ���ļ���  ...\webPage.html  
int ir=SendDlgItemMessage(hdlg, IDC_COMBO1, CB_GETCURSEL, 0,0);   
SendDlgItemMessage(hdlg, IDC_COMBO1,  CB_GETLBTEXT, ir,(long)szURL);     // Ŀ����ַ  -- ע�� WM_GETTEXT ���� 
SendDlgItemMessage(hdlg, IDC_COMBO2, WM_GETTEXT, 256,(long)szFile);      // ���Ŀ¼ -- Ҳ�������ļ���   

bool bHtm=false; 
// �ȸ��� URL ���� szFile: 
char*r=strrchr(szURL,'.');  
if(r && 0==strnicmp(r,".htm",4) ) { bHtm=true;  
r=strrchr(szURL,'\\');
if(!r) r=strrchr(szURL,'/');
if(r){
char*s=strrchr(szFile,'\\');   
if(!s) s=strrchr(szFile,'/'); 
if(s){ strcpy(s, r);} 
}} 


r = strrchr(szFile, '.'); 
if(r)*r=0; 

if (-1==access(szFile,0)){ // �����ҳ������ļ���Ŀ¼��, ����ҳ����ͬ, ��Ĭ��Ϊ [dwnPage] 
ir=MessageBox(0,szFile, "Ŀ¼������,�Ƿ񴴽�?", MB_YESNO);
if(ir==IDYES)CreateDirectory(szFile,0L);  
} 

if(r) *r='.'; else strcat(szFile,".html");

// printf("\r\n��ַ[%s]\r\n", szURL);  printf("����[%s]\r\n\r\n", szFile);

if(bHtm){
SendDlgItemMessage(hdlg, IDC_COMBO2,CB_INSERTSTRING,1,(long)szFile);
SendDlgItemMessage(hdlg, IDC_COMBO2,CB_SETCURSEL,1,0);
}else{
SendDlgItemMessage(hdlg, IDC_COMBO2,CB_SETCURSEL,0,0);
}

#endif    // DIR_NAME 

}break;





case IDCANCEL:{    // ת�����������λ��  
char * szFile=new char[256]; 

if(!GetFolder(szFile,"D:\\Tbyang20\\��Դ"))break;    // ���� "D:/Tbyang20" ��ʽ 

SendDlgItemMessage(hdlg, IDC_COMBO2, CB_INSERTSTRING, 0, (long)szFile); 
SendDlgItemMessage(hdlg, IDC_COMBO2, CB_SETCURSEL, 0,0); 

delete[] szFile; 
}break;  



default:break;  
}  // switch(wmId)

} break; // WM_COMMAND

default:break;  //switch (uMsg)
}

return FALSE;
}



#endif     // DIALOG_UI


 