



#ifndef _INTERACT_H_
#define _INTERACT_H_    // #endif  // _INTERACT_H_ //

// �ṹ���� INTERACT.CPP ��ʵ��
#ifdef  _INTERACT_CPP_    // #define   _INTERACT_CPP_  
#define INTERACT_EXTERN 
#else 
#define INTERACT_EXTERN extern 
#endif  // _INTERACT_CPP_ //

#include <Windows.h> 

inline HWND&GetIE(){static HWND hIE;  return hIE; }

void IE_open(const char* url);  
void IE_open(const wchar_t* url);  


// һ�����  

#if COMMON_OPS|1


HANDLE RunProcess( const char*cmdLine, const char* szParam=0L, int iCmdShow=SW_SHOW );    



HWND FindWnd(HWND hParent,  const wchar_t* WndCls,  const wchar_t* Title =0); 

void Tap(HWND hWnd=0, int x=0, int y=0);  



#endif    // COMMON_OPS









#endif  // _INTERACT_H_ //






