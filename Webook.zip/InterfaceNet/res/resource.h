//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� InterfaceNet.rc ʹ��
//
#define IDC_BUTTON1                     3
#define IDR_MENU1                       101
#define IDD_DIALOG1                     102
#define IDR_MENU2                       103
#define IDD_DIALOG0                     107
#define IDC_COMBO1                      1000
#define IDC_STATIC1                     1000
#define IDC_COMBO2                      1001
#define IDC_EDIT1                       1002
#define IDC_COMBO12                     1005
#define IDC_COMBO11                     1006
#define IDC_GET                         40001
#define IDC_START                       40002
#define IDC_TRACE                       40003
#define IDC_POST                        40003
#define IDC_TEST                        40004
#define IDC_STOP                        40005
#define IDC_CLEAR                       40006
#define IDC_CLS2                        40007
#define IDC_EXIT                        40008
#define ID_40009                        40009
#define IDO_CONFIG                      40009
#define ID_40010                        40010
#define IDH_IP                          40011
#define ID_40012                        40012
#define ID_40013                        40013
#define IDO_CANCELL                     40013
#define ID_DOWNPAGE                     40014
#define IDC_DOWNPAGE                    40015
#define IDO_LAMDAN                      40015
#define ID_40016                        40016
#define IDT_DELADDR                     40017
#define IDT_DELDIR                      40018
#define ID_40019                        40019
#define IDT_TEST                        40019
#define IDT_DELLADDR                    40020
#define IDO_01                          40020
#define ID_40021                        40021
#define IDT_HTTPS                       40022
#define IDP_SPLIT                       40023
#define ID_40023                        40023
#define IDT_RSP                         40024
#define IDP_INVERT                      40025
#define IDP_EDGE                        40027
#define IDP_BINV                        40029
#define IDH_ABOUT                       40032
#define IDV_PIXEL                       40034
#define IDV_NORMAL                      40035
#define IDV_HISTOGRAM                   40036
#define IDF_SAVE                        40038
#define IDT_HISTO                       40041
#define IDT_ADD                         40043
#define IDE_CUT                         40045
#define IDE_AMP                         40047
#define IDE_GRAY                        40048
#define IDP_CS                          40050
#define IDP_HISTO                       40052
#define IDV_ADD                         40054
#define IDV_GROW                        40055
#define IDV_MONO                        40057
#define IDE_UNDO                        40060
#define IDF_EXIT                        40061
#define IDF_NEW                         40063
#define IDF_OPEN                        40064
#define IDW_CASCADE                     40066
#define IDW_CLOSE                       40070
#define IDW_CLOSEALL                    40072
#define IDP_CLS                         40074
#define IDP_CRIC                        40077
#define IDP_CLSR                        40081
#define IDP_SHRINK                      40083
#define IDE_24S                         40086
#define IDT_TESS                        40087
#define IDT_TESS4                       40091
#define IDT_REC                         40094
#define IDE_SORT                        40095
#define IDE_WORD                        40096

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40025
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
