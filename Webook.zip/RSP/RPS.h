
#ifndef _RPS_H_
#define _RPS_H_    // #endif  // _RPS_H_ //

// �ṹ���� RPS.CPP ��ʵ��
#ifdef  _RPS_CPP_    // #define _RPS_CPP_ 
#define RPS_EXTERN 
#else 
#define RPS_EXTERN extern 
#endif  // _RPS_CPP_ //


#include <Windows.h>



int main_RPS(); 
 
int main_Net();




#endif  // _RPS_H_ //



