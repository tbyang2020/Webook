



#ifndef _GETLINK_H_
#define _GETLINK_H_    // #endif  // _GETLINK_H_ //

// �ṹ���� GETLINK.CPP��ʵ��
#ifdef  _GETLINK_CPP_    // #define   _GETLINK_CPP_ //
#define GETLINK_EXTERN 
#else 
#define GETLINK_EXTERN extern 
#endif  // _GETLINK_CPP_ //

#include <Windows.h>
 


int GetLinks(char* szt, const char* URL, const char* szHtm);  


int GetURI(const char* URL, const char* szFile);  
int ParseURL(const char* url, char* ptr_host, char* ptr_uri);  
int GetRes(const char* szt, const char* URL, const char* szHtm);


DWORD WINAPI GetLink(void*pa);     // const char*URL=0, void*pen, const char*Save=0 



#endif  // _GETLINK_H_ //






