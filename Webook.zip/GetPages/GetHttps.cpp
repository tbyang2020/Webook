


#define   _GETHTTPS_CPP_  

#define   _WINSOCK_DEPRECATED_NO_WARNINGS    // gethostbyname �� GetAddrInfoW    
#define   _CRT_SECURE_NO_WARNINGS             // fopen_s 



#include <WINSOCK2.H> 
 
#include "openssl/ssl.h"
#include "openssl/err.h"
 

// #include <iostream>
// #include <sstream>
 
//#pragma comment(lib,"openssl/libs/libeay32.lib")
//#pragma comment(lib,"openssl/libs/ssleay32.lib")



#pragma comment(lib,"ws2_32.lib")

#pragma comment(lib,"GetPages/openssl/lib/libcrypto.lib")
#pragma comment(lib,"GetPages/openssl/lib/libssl.lib")


 
// using namespace std;
 

#include "InterfaceNet/InterfaceNet.h"
#include "InterfaceNet/qTrace.h"

//#include "GetPages.h"

//#include "Interact.h"
#include  "GetHttps.h"





// ao ��β��Ҫ�� "\r\n",  ���Զ�����  
#define Printf( ao, ... )   { static char g_buf[1024];  g_buf[0]=0;  \
sprintf(g_buf, ao, ##__VA_ARGS__);   SendDlgItemMessage(GetMainDlg(),IDC_EDIT1, EM_REPLACESEL, 0, (long)g_buf);  } 



#define PRT( ao, ... )   { static char g_buf[1024];  g_buf[0]=0;  \
int ip_=sprintf(g_buf, "Ln%d %s\t   ", __LINE__,  strrchr( __FILE__ , '\\') +1 );  \
ip_+=sprintf(g_buf+ip_, ao, ##__VA_ARGS__);   \
SendDlgItemMessage(GetMainDlg(),IDC_EDIT1, EM_REPLACESEL, 0, (long)g_buf);  } 



 // ao ��β��Ҫ�� "\r\n",  ���Զ�����  
#define PRN( s, n )  // { if(strlen(s)<=(n))  SendDlgItemMessage(GetMainDlg(),IDC_EDIT1, EM_REPLACESEL, 0, (long)s);  \
else{ char c=*(s+(n)); *(s+(n))=0; SendDlgItemMessage(GetMainDlg(),IDC_EDIT1, EM_REPLACESEL, 0, (long)s); *(s+(n))=c; }} 










int GetURI(const char*URL){   // , const char* szFile 





static char g_URL[256]={0};  

if(g_URL[0]!=0) if(strcmp(g_URL, URL)==0 ){ printf("�ظ���Դ:%s\r\n", URL);  return 0; }

strcpy(g_URL, URL);  


char host[256]={0}, uri[256]={0};  
// strcpy(host,"www.buyiju.com");  strcpy(uri,"/zhouyi/");    // host="www.buyiju.com";   uri="/zhouyi/";  
int port = ParseURL(URL,host,uri); 
if(port==-1) { qTrace("host=%s\r\nuri=%s\r\nport=%d\r\n",host, uri, port);  return 0; }


// if(strstr(URL,"www.sitemeter.com")) Printf("%s\r\nhost=%s\r\nuri=%s\r\nport=%d\r\n",URL, host, uri, port);

// if(port==443)  Printf("%s\r\nhost=%s\r\nuri=%s\r\nport=%d\r\n",URL, host, uri, port);


char szFile[256]={0};  

char*p=strrchr(uri,'.'); 
if(!p) strcpy(szFile,"UnknownURI.txt"); 
else{
p=strrchr(uri, '\\');
if(!p) p=strrchr(uri, '//');
if(p) strcpy(szFile,p+1); 
else  strcpy(szFile, uri);
}

FILE*fp=fopen(szFile,"wb");  if(!fp){ MessageBox(0,szFile,strerror(errno),0);  abort(); }






#if CONNECT_HOST|1

SOCKET soc = socket(AF_INET,SOCK_STREAM,0);  // IPPROTO_TCP
if(soc == INVALID_SOCKET) {  qTrace("\r\nsocket error %d ",WSAGetLastError());   return 0;  }


hostent *ip = gethostbyname(host);
if (!ip) {  qTrace("\r\n�����޷�������ip, ���� %d",WSAGetLastError()); closesocket(soc);  return 0;  }  


sockaddr_in sn={AF_INET, htons(port), *(in_addr*)ip->h_addr_list[0], };
//  sn.sin_family = AF_INET;     sn.sin_port = htons(port);  sn.sin_addr = *(in_addr*)ip->h_addr_list[0];
	
// if(connect(soc,(sockaddr*)&sn,sizeof(sn)) == SOCKET_ERROR) { qTrace("connect error -1\r\n");   return 0; }
	

int n = SOCKET_ERROR;  // connect(soc, (sockaddr*)&sa, sizeof(sa));  // ������ bind Ҳ����  // int n = bind(sock, (sockaddr*)&sa, sizeof(sa));   (n == SOCKET_ERROR) {  cout << "bind����ʧ�ܣ� �����룺 " << WSAGetLastError() << endl;  return 0;  }  

int j=0;  while(n==SOCKET_ERROR ){ if(j==0) Printf("��������ʧ��:\r\n%s\r\n%s\r\n", host, URL); j++;   n = connect(soc, (sockaddr*)&sn, sizeof(sn));   if(j>4) break; Sleep(10); }   // ʵ������Ӽ��� ......? ��Ч��!

if (n == SOCKET_ERROR){ qTrace("\r\nconnect ʧ��, ���� %d", WSAGetLastError());  closesocket(soc);  return INVALID_SOCKET;  }  

//Printf("Host connected\t[%s]\r\nsoc=0x%X, g_so=0x%X\r\n\r\n",  host, soc, getSocket() );


#endif    // CONNECT_HOST



#if CONNECT_SSL|1

SSL_CTX* ctx=0;  
SSL*ssl=0; 

if (port == 443) {


SSL_library_init(); \
ERR_load_BIO_strings();  \
SSL_load_error_strings();  \
OpenSSL_add_all_algorithms();

//	SSL_load_error_strings();	    // ����SSL������Ϣ 
//	SSLeay_add_ssl_algorithms();	// ����SSL�ļ���/HASH�㷨 

const SSL_METHOD *meth = SSLv23_client_method();	// �ͻ���, �����ѡ��SSLv23_server_method()   //  ssl Э��汾2��3  

ctx = SSL_CTX_new(meth);	// �����µ�SSL������ 
if( !ctx ) { qTrace("\r\nSSL_CTX_new error %d!\r\n", GetLastError() ); return 0; }
		
ssl = SSL_new(ctx);   // ����SSL 
if( !ssl ) {  qTrace("\r\nSSL_new error %d", WSAGetLastError());  return 0; }

// SSL_CTX_load_verify_locations(ctx,ROOTCERTF,NULL);
// SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, 0);

if(!SSL_set_tlsext_host_name(ssl, host)){   Printf( "\n\nWARNING: failed to configure server name indication (SNI) " "TLS extension\n\n"); }

SSL_set_fd(ssl,soc);   // ��SSL��TCP SOCKET ���� 
	
int ret = SSL_connect(ssl);  // SSL���� 


if(ret==1){ Printf("\r\n\r\nSSL_connect successful! [%s]\r\n\r\n", host);
}else{      Printf("\r\n\r\nSSL_connect ��������ʧ�� [%s]\r\n[%s]\r\n", host, URL); }

if (ret == -1) {

int ic=0; 
while(ret==-1){  

if(ic%5==0) Printf("\r\nSSL_connect=%d,  detail= %d ", ret, SSL_get_error(ssl, ret)  );
// SSL_ERROR_WASSL_ERROR_SYSCALL=5

Sleep(100); 
ret = SSL_connect(ssl);    

ic++; if(ic>30) break;  
}

if(ret == -1) { Printf( "\r\nSSL_connect ʧ��! [%s]\r\n[%s]\r\n", host, URL  );  return 0; }
else            Printf("\r\n\r\nSSL_connect successful after trying! [%s]\r\n\r\n", host);
	
}    // if (ret == -1)
	


}  // if(port==443)  
	
#endif    // CONNECT_SSL



const int iPK=1024;  
int nc=1024*100;       // �ڴ����rrr���� 100K 
char*szt = (char*)malloc(nc+1*32);  *szt=0; 


// string  reqInfo = "GET " +(string)othPath+ " HTTP/1.1\r\nHost: " + (string)host + "\r\nConnection:Close\r\n\r\n";  
int ic=sprintf(szt, "GET %s HTTP/1.1\r\n"  \
//"Accept: */*\r\n"             // stream << "Accept-Encoding: gzip, deflate, br\r\n";  // ��Ҫ����, ���򻹵ö�һ������Ĳ���
"Host:%s\r\n"                // "Host:%s\r\n" 
//"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134\r\n" 
"Connection:Close\r\n\r\n",   //  "Connection: Keep-Alive\r\n" 
uri, host);   


// string s = stream.str(); const char *sendData = s.c_str();	strcpy(szt,s.c_str()); ir=strlen(szt);  

int ir =0;   

if(port==443) ir=SSL_write(ssl,szt,ic);    //  
else          ir=send(soc,szt,ic,0);       //  ����������http�����ַ��� ......   
if(ir== -1){ qTrace("SSL write error !");    delete[] uri, host; free(szt); closesocket(soc); return 0;  }  


// Printf("\r\nrequest sent: �� %d / %d\r\n%s\r\n", ir,ic, szt);



int ict=0;
ic=0;       // ic ת���ڼ����ڴ�������     



#if RECV_PAGE|1


if(port==443){

while( ( ir=SSL_read(ssl,szt+ict,iPK) )   >0  ){   // if(ir<=0){ printf("\r\nrecv =0 ... \r\n\r\n"); break; }

ict += ir;  

if( ict+iPK>=nc){   ic++;   if(0)Printf("\r\n%d\t  ir=%d, ict+iPK=%dK , nc=%dK ",  ic, ir,  ict+iPK , nc/1024);   // ������ 1K �������� 
nc+=iPK*100;  szt = (char*)realloc(szt, nc+128);    
}  

szt[ict] = 0;  // Printf("ic=%d\r\n", ic);
if(ic>1024) break;    // ���ݹ���!  
}  // while  



}else{


while( (ir =recv(soc,szt+ict,iPK,0) ) >0){   // if(ir<=0){ printf("\r\nrecv =0 ... \r\n\r\n"); break; }

ict += ir;  

if( ict+iPK>=nc){   ic++;   if(0)printf("\r\n%d\t  ir=%d, ict+iPK=%dK , nc=%dK ",  ic, ir,  ict+iPK , nc/1024);   // ������ 1K �������� 
nc+=iPK*100;  szt = (char*)realloc(szt, nc+128);    
}  

szt[ict] = 0;  // printf("ir=%d\r\n", ir);
if(ic>1024) break;    // ���ݹ���!  
}  // while  


}  // if(port==443)







// closesocket(scr);   // ������Դ�ļ���Ҫ��! Connection:Close ���ùر�. 

// Printf("\r\nic=%d\t  ict=%d, nc=%dK \r\n\r\n",  ic,  ict, nc/1024); 

#endif  // RECV_PAGE 






if (fp) {
char*p= szt;  
p= strstr(szt,"\r\n\r\n");  if(p){ p+=4; ict-=(p-szt); }else p=szt;  
fwrite(p,1,ict, fp);   // fprintf(fp, "%s", p); 
fclose(fp);
}

// Printf("OK\r\n");
	

#if OPEN_PAGE|1

ShellExecuteA(0, "open", szFile, 0,0,1);  // ShellExecute(0,0,szFile,0,0,SW_SHOWNORMAL);  // ShellExecute(0,"open","iexplore","a.html",0,SW_SHOW);

//InvalidateRect(GetMainDlg(),0,1);
//IE_open(szFile); 

#endif  // OPEN_PAGE








#if CLEAN_SSL|1

if(port==443){ 
SSL_shutdown(ssl);	// �ر�SSL�׽��� 
SSL_free(ssl);      // �ͷ�SSL�׽��� 
SSL_CTX_free(ctx);	// �ͷ�SSL�Ự���� 
}    //  if(port==443)   

#endif  


closesocket(soc);  // WSACleanup();

free( szt );
return ict;
}
 







// SOCKET& getSocket();    // GetPages.cpp   

int GetURI(const char*URL, const char* szFile){    

static char g_URL[256]={0};  

if(g_URL[0]!=0) if(strcmp(g_URL, URL)==0 ){ Printf("�ظ���Դ:%s\r\n", URL);  return 0; }

strcpy(g_URL, URL);  


char host[256]={0}, uri[256]={0};  
// strcpy(host,"www.buyiju.com");  strcpy(uri,"/zhouyi/");    // host="www.buyiju.com";   uri="/zhouyi/";  
int port = ParseURL(URL,host,uri); 
if(port==-1) { qTrace("host=%s\r\nuri=%s\r\nport=%d\r\n",host, uri, port);  return 0; }


// if(strstr(URL,"www.sitemeter.com")) Printf("%s\r\nhost=%s\r\nuri=%s\r\nport=%d\r\n",URL, host, uri, port);

// if(port==443)  Printf("%s\r\nhost=%s\r\nuri=%s\r\nport=%d\r\n",URL, host, uri, port);



#if CONNECT_HOST|1

SOCKET soc = socket(AF_INET,SOCK_STREAM,0);  // IPPROTO_TCP
if(soc == INVALID_SOCKET) {  qTrace("\r\nsocket error %d ",WSAGetLastError());   return 0;  }


hostent *ip = gethostbyname(host);
if (!ip) {  qTrace("\r\n�����޷�������ip, ���� %d",WSAGetLastError()); closesocket(soc);  return 0;  }  


sockaddr_in sn={AF_INET, htons(port), *(in_addr*)ip->h_addr_list[0], };
//  sn.sin_family = AF_INET;     sn.sin_port = htons(port);  sn.sin_addr = *(in_addr*)ip->h_addr_list[0];
	
// if(connect(soc,(sockaddr*)&sn,sizeof(sn)) == SOCKET_ERROR) { qTrace("connect error -1\r\n");   return 0; }
	

int n = SOCKET_ERROR;  // connect(soc, (sockaddr*)&sa, sizeof(sa));  // ������ bind Ҳ����  // int n = bind(sock, (sockaddr*)&sa, sizeof(sa));   (n == SOCKET_ERROR) {  cout << "bind����ʧ�ܣ� �����룺 " << WSAGetLastError() << endl;  return 0;  }  

int j=0;  while(n==SOCKET_ERROR ){ if(j==0) Printf("��������ʧ��:\r\n%s\r\n%s\r\n", host, URL); j++;   n = connect(soc, (sockaddr*)&sn, sizeof(sn));   if(j>4) break; Sleep(10); }   // ʵ������Ӽ��� ......? ��Ч��!

if (n == SOCKET_ERROR){ qTrace("\r\nconnect ʧ��, ���� %d", WSAGetLastError());  closesocket(soc);  return INVALID_SOCKET;  }  

//getSocket()=soc;   // ������Դʱʹ��  
//Printf("Host connected\t[%s]\r\nsoc=0x%X, g_so=0x%X\r\n\r\n",  host, soc, getSocket() );


#endif    // CONNECT_HOST



#if CONNECT_SSL|1

SSL_CTX* ctx=0;  
SSL*ssl=0; 

if (port == 443) {


SSL_library_init(); \
ERR_load_BIO_strings();  \
SSL_load_error_strings();  \
OpenSSL_add_all_algorithms();

//	SSL_load_error_strings();	    // ����SSL������Ϣ 
//	SSLeay_add_ssl_algorithms();	// ����SSL�ļ���/HASH�㷨 

const SSL_METHOD *meth = SSLv23_client_method();	// �ͻ���, �����ѡ��SSLv23_server_method()   //  ssl Э��汾2��3  

ctx = SSL_CTX_new(meth);	// �����µ�SSL������ 
if( !ctx ) { qTrace("\r\nSSL_CTX_new error %d!\r\n", GetLastError() ); return 0; }
		
ssl = SSL_new(ctx);   // ����SSL 
if( !ssl ) {  qTrace("\r\nSSL_new error %d", WSAGetLastError());  return 0; }

// SSL_CTX_load_verify_locations(ctx,ROOTCERTF,NULL);
// SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, 0);

if(!SSL_set_tlsext_host_name(ssl, host)){   Printf( "\n\nWARNING: failed to configure server name indication (SNI) " "TLS extension\n\n"); }

SSL_set_fd(ssl,soc);   // ��SSL��TCP SOCKET ���� 
	
int ret = SSL_connect(ssl);  // SSL���� 


if(ret==1){ Printf("\r\n\r\nSSL_connect successful! [%s]\r\n\r\n", host);
}else{      Printf("\r\n\r\nSSL_connect ��������ʧ�� [%s]\r\n[%s]\r\n", host, URL); }

if (ret == -1) {

int ic=0; 
while(ret==-1){  

if(ic%5==0) Printf("\r\nSSL_connect=%d,  detail= %d ", ret, SSL_get_error(ssl, ret)  );
// SSL_ERROR_WASSL_ERROR_SYSCALL=5

Sleep(100); 
ret = SSL_connect(ssl);    

ic++; if(ic>30) break;  
}

if(ret == -1) { Printf( "\r\nSSL_connect ʧ��! [%s]\r\n[%s]\r\n", host, URL  );  return 0; }
else            Printf("\r\n\r\nSSL_connect successful after trying! [%s]\r\n\r\n", host);
	
}    // if (ret == -1)
	


}  // if(port==443)  
	
#endif    // CONNECT_SSL



const int iPK=1024;  
int nc=1024*100;       // �ڴ����rrr���� 100K 
char*szt = (char*)malloc(nc+1*32);  *szt=0; 


// string  reqInfo = "GET " +(string)othPath+ " HTTP/1.1\r\nHost: " + (string)host + "\r\nConnection:Close\r\n\r\n";  
int ic=sprintf(szt, "GET %s HTTP/1.1\r\n"  \
//"Accept: */*\r\n"             // stream << "Accept-Encoding: gzip, deflate, br\r\n";  // ��Ҫ����, ���򻹵ö�һ������Ĳ���
"Host:%s\r\n"                // "Host:%s\r\n" 
//"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134\r\n" 
"Connection:Close\r\n\r\n",   //  "Connection: Keep-Alive\r\n" 
uri, host);   


// string s = stream.str(); const char *sendData = s.c_str();	strcpy(szt,s.c_str()); ir=strlen(szt);  

int ir =0;   

if(port==443) ir=SSL_write(ssl,szt,ic);    //  
else          ir=send(soc,szt,ic,0);       //  ����������http�����ַ��� ......   
if(ir== -1){ qTrace("SSL write error !");    delete[] uri, host; free(szt); closesocket(soc); return 0;  }  


// Printf("\r\nrequest sent: �� %d / %d\r\n%s\r\n", ir,ic, szt);



int ict=0;
ic=0;       // ic ת���ڼ����ڴ�������     



#if RECV_PAGE|1


if(port==443){

while( ( ir=SSL_read(ssl,szt+ict,iPK) )   >0  ){   // if(ir<=0){ printf("\r\nrecv =0 ... \r\n\r\n"); break; }

ict += ir;  

if( ict+iPK>=nc){   ic++;   if(0)Printf("\r\n%d\t  ir=%d, ict+iPK=%dK , nc=%dK ",  ic, ir,  ict+iPK , nc/1024);   // ������ 1K �������� 
nc+=iPK*100;  szt = (char*)realloc(szt, nc+128);    
}  

szt[ict] = 0;  // Printf("ic=%d\r\n", ic);
if(ic>1024) break;    // ���ݹ���!  
}  // while  



}else{


while( (ir =recv(soc,szt+ict,iPK,0) ) >0){   // if(ir<=0){ printf("\r\nrecv =0 ... \r\n\r\n"); break; }

ict += ir;  

if( ict+iPK>=nc){   ic++;   if(0)printf("\r\n%d\t  ir=%d, ict+iPK=%dK , nc=%dK ",  ic, ir,  ict+iPK , nc/1024);   // ������ 1K �������� 
nc+=iPK*100;  szt = (char*)realloc(szt, nc+128);    
}  

szt[ict] = 0;  // printf("ir=%d\r\n", ir);
if(ic>1024) break;    // ���ݹ���!  
}  // while  


}  // if(port==443)







// closesocket(scr);   // ������Դ�ļ���Ҫ��! Connection:Close ���ùر�. 

// Printf("\r\nic=%d\t  ict=%d, nc=%dK \r\n\r\n",  ic,  ict, nc/1024); 

#endif  // RECV_PAGE 


// GetLinks(szt, URL, szFile);



FILE*fp=fopen(szFile,"wb");  if(!fp){ MessageBox(0,szFile,strerror(errno),0);  abort(); }

if (fp) {
char*p= szt;  
p= strstr(szt,"\r\n\r\n");  if(p){ p+=4; ict-=(p-szt); }else p=szt;  
fwrite(p,1,ict, fp);   // fprintf(fp, "%s", p); 
fclose(fp);
}

// Printf("OK\r\n");
	

#if OPEN_PAGE|0

// ShellExecuteA(0, "open", szFile, 0,0,1);  // ShellExecute(0,0,szFile,0,0,SW_SHOWNORMAL);  // ShellExecute(0,"open","iexplore","a.html",0,SW_SHOW);

InvalidateRect(GetMainDlg(),0,1);
IE_open(sFile); 

#endif  // OPEN_PAGE








#if CLEAN_SSL|1

if(port==443){ 
SSL_shutdown(ssl);	// �ر�SSL�׽��� 
SSL_free(ssl);      // �ͷ�SSL�׽��� 
SSL_CTX_free(ctx);	// �ͷ�SSL�Ự���� 
}    //  if(port==443)   

#endif  


closesocket(soc);  // WSACleanup();

free( szt );
return ict;
}
 
 

















// szt Ϊ recv ���յ�������, ���������ظ�ͷ, �� "\r\n\r\n" ֮ǰ�Ĳ���.  dir Ϊ��ҳ�ļ�����Ŀ¼����Ŀ¼,   
// ��ҳ�е���Դ��ַһ���������ҳ�� URL

//  szHtm Ϊ��ҳ����·��.   

int GetLinks(char* szt, const char*URL, const char*szHtm){


char host[256]={0}, host_buf[256]={0}, file[256]={0};   // strcpy(file, dir);  
 
#if DEFAULT_HOST|1

// �������� URL PATH �� host: host --- uri    
// Http://www.baidu.com                           --->   Http://www.baidu.com     
// http://www.faithfreedom.org/Articles/Sira.htm  --->   http://www.faithfreedom.org/Articles      

strcpy(host, URL);  
 
if(0) {  const char*u=strstr(URL, "//");  if(!u) u=URL; else u+=2;   strcpy(host, u); }

char*v= strrchr(host, '/');   
if(v) if( v-host>7) *v=0;      //    https://www.baidu.com/  ��  https://www.baidu.com ��ͬ,  ���� host ��ͬ, Ϊ  https://www.baidu.com  

int    iv=strlen(host);    

#endif    //  DEFAULT_HOST 


strcpy(file, szHtm);  v=strrchr(file, '.'); if(v) *v=0;    // ���� "...\Dir/File.html" ���� "...\Dir/File",    "...\Dir/File/*.gif"     
int   iw=strlen(file);  




 
char c, u, *p, *q, *r,    *t;     // ����ָ�� 
 
// ��д��ַ  -- �չ˵� utf8 �������ҳ, ��Ҫʹ������������Դ��ŵ�Ŀ¼! 
// <  ... href = '....../...' ...>
// <  ... src  = '....../....../...' ...>  .........
//        p       q     w      s   r    t           T
 

char*po=strstr(szt, "\r\n\r\n");
if (po) po+=4; else po=szt; 
 
int ict=strlen(po);   // int ic = ict - (p-szt); 
 


char*ptr=po;  
int ic=0;    // ѭ������ 
 

char* h;  


while(ptr<po+ict){  //  ic++; if(ic>8){ if(1)MessageBox(0,"��Դ����!",0,0); break; }

if(*ptr==0) break; 

 
p=strstr(ptr,"src");  if(!p)  break;    // ����ǲ��� src='...' �� src="..."

ptr=p+3;  
 
if( ptr-po < 128 ) printf("ptr-po=%d\r\n", ptr-po );

//           ptr
// <  ... src  = '....../.........' ...>  .........
//        p       q               r                 

#if CUT_ADDR|1

q=ptr;  while( isspace(*q) ) q++;  if(*q!='=') { PRN(ptr,10);    continue;  }
 
q++; while (isspace(*q)) q++;  





if(*q!='\'' && *q!='"'){ PRN(ptr, (q-ptr)+10);     continue;  }  // Ҫ�� src='...' �� src="..."

c=*q;    // assert(*q=='\'' || *q=='"');  


q++;   // ��Դ��ַ --- �ض���  


r=q;  while(*r!=0){if( *r==c || *r=='>' ) break;  r++; }
if(*r==0) { PRN(ptr, (r-q)+10); break;   }
if(*r!=c) { PRN(ptr, (r-q)+10); break;   }

*r=0;   // c=*r;   c= '  �� c= " 

ptr=r+1;  



if(strstr(q,"sm7.sitemeter.com"))  if(0)printf("q=%s\r\n\r\n", q);   // ../lcurv.gif    top.gif  




#if CHAR_SPEC|1   // ��ȥ HTML anchor ��־���� #?&  -- GET �������� 

//  https://www.sitemeter.com/js/counter.js?site=sm7freefree
//  q                                     t                r         
//                                        u

t=strchr(q,'#');   if(!t) t=strchr(q,'?');   if(!t) t=strchr(q,'&');  if(t){ u=*t; *t=0;  }

#endif  // CHAR_SPEC 

#endif  // CUT_ADDR


h=0;  // �ض�����Դ��ַ -- ����ԡ�����·��,  
#if MAKE_HOST|1

h=q;   // ����   <input type="image" alt="Make payments with PayPal - it's fast, free and secure!" src="https://www.paypal.com/images/x-click-but21.gif" border="0" name="I13">



if(*h=='/' && *(h+1)=='/' ){  // ʡ�� https �� http �����,  ����   "//i.buyiju.com/img/zhouyi/zxt000000.jpg"

strcpy(host_buf,"https:");   strcat(host_buf, q);  h=host_buf;      //  https://i.buyiju.com/img/zhouyi/zxt000000.jpg   -->  //i.buyiju.com/img/zhouyi/zxt000000.jpg  -->   https://www.buyiju.com/zhouyi/img/zhouyi/zxt010001.jpg  �Ǵ����  
                      
}else if(strnicmp(h,"http", 4)!=0){  // ���� http ��ͷ, ��Ϊ��Ե�ַ, ���� host ��������. ����      <img src="../_borders/banner1.jpg" border="0" width="600" height="86">


h=host;  h[iv]=0;      


if(*q=='/' && *(q+1) =='/'){ char*t=strchr(q+3,'/'); if(t) strcat(h,t);  }   //  q="//www.baidu.com/img/flexible/logo/pc/index.png" ��������ҳ���� --- ���ǵ�, Ӧ�ü��� "http[s]".  
else{  strcat(h,"/"); strcat(h,q); }

if(0)qTrace("h=%s\r\nhost=%s\r\nq=%s", h, host,q);



}    // else   printf("\r\nq=%s\r\nh=%s\r\n", q, h);  



#endif    // MAKE_HOST 



 
#if MAKE_FILE|1     // ͨ�� szHtm ���ɱ����ļ�����Զ����Դ��Ե�ַ 

// src="top.gif"  �������������!  


file[iw]=0;        
v=strrchr(q, '/');  if(!v) v=strrchr(q,'\\');  
if(v) strcat(file,v);  
else {  // printf("q=%s\r\n", q);
strcat(file,"\\"); strcat(file,q); 
}

// if(strstr(h,"sm7.sitemeter.com"))  if(1)printf("q=%s\r\n\r\n", q);   // ../lcurv.gif    top.gif  



#endif    //  MAKE_FILE


 


if( strlen(h)==7 ){ if(0)printf("h=%s\r\n", h); if(t) *t=u;  *r=c;    continue;  }    // �ܿ� src='http://' 

// if( strstr(h,"top.gif")  ){ printf("h=%s\r\n", h); if(t) *t=u;  *r=c;    continue;  }    // �ܿ� src='top.gif' 




if( ic%10==0  ) printf("ic=%d,  h=%s\r\n", ic, h);

ic += GetURI(h, file); 
  



if(t) *t=u;  

assert(t<r); 


// ��Դ��ַ��������
 
#if MOVE_MEM|1
 
// <  ... src  = '....../...' ...>  .........
//        p       q         r                T
// <  ... src  = 'File/...' ...>  .........
//        p       q       r                T

file[iw]=0;     
v=strrchr(file,'/');  if(!v) v=strrchr(file,'\\');  if(!v)v=file; else v++;     
int id=strlen(v);     //  "...\Dir/File"      --->    "File"  

char*T=strrchr(r+1, 0);  if(!T) { qTrace("szt=%s", szt); break; }
 
t=strrchr(q,'/');   // if(!t) printf("\r\nid=%d, q=%s\r\n", id, q); 
 
if(!t){ t=q; strcat(v,"/"); id++; }

memmove(q+id, t, T-t+1);   // ������β0

memcpy(q,v, id);
 

#endif    // MOVE_MEM   


r=strchr(q,0); if(r-q>128) { qTrace("q=%s\r\n", q); };     //  ��ʱ�Ѿ�����ʹ�� q  
*r=c;  
 
// ptr=p+3;  
}  // while (*ptr);  


return ic;  // links count 
}













// GetPages  // const char*URL, const char*Save

DWORD WINAPI GetHttps(void*param){     

WSADATA wsa;	if(WSAStartup(MAKEWORD(2,2),&wsa)!=0){  Printf("\r\nWSAStartup error %d",  WSAGetLastError() );  return -1;}    // ������Щ��������� WSAClean! 

// URL = "https://www.buyiju.com/zhouyi/";   

	
struct PARAM{const char*URL; const char* szHtm; } *pa=(PARAM*)param;
if (!pa || !pa->URL){ qTrace("��������\r\n"); return 0; }



char host[256]={0}, uri[256]={0};   // strcpy(host,"www.buyiju.com");  strcpy(uri,"/zhouyi/");    // host="www.buyiju.com";   uri="/zhouyi/";  
int port = ParseURL(pa->URL,host,uri); 
if(port==-1) { qTrace("host=%s\r\nuri=%s\r\nport=%d\r\n",host, uri, port);  return 0; }




#if CONNECT_HOST|1

SOCKET soc = socket(AF_INET,SOCK_STREAM, IPPROTO_TCP);  // 0
if(soc == INVALID_SOCKET) {  qTrace("\r\nsocket error %d ",WSAGetLastError());   return 0;  }


hostent *ip = gethostbyname(host);
if (!ip) {  qTrace("\r\n�����޷�������ip, ���� %d",WSAGetLastError()); closesocket(soc);  return 0;  }  


Printf("\r\nconnecting %s [%s] ...... \r\n", inet_ntoa( * (in_addr*)ip->h_addr_list[0] ),  host);

sockaddr_in sn={AF_INET, htons(port), *(in_addr*)ip->h_addr_list[0], };

//  sn.sin_family = AF_INET;     sn.sin_port = htons(port);  sn.sin_addr = *(in_addr*)ip->h_addr_list[0];   \
 if(connect(soc,(sockaddr*)&sn,sizeof(sn)) == SOCKET_ERROR) { qTrace("connect error -1\r\n");   return 0; }
	




int n = SOCKET_ERROR;   // connect(soc, (sockaddr*)&sa, sizeof(sa));  // ������ bind Ҳ����  // int n = bind(sock, (sockaddr*)&sa, sizeof(sa));   (n == SOCKET_ERROR) {  cout << "bind����ʧ�ܣ� �����룺 " << WSAGetLastError() << endl;  return 0;  }  

int j=0;  while(n==SOCKET_ERROR ){ if(j>0) Printf("\r\nconnect %d \r\n", j); j++;   n = connect(soc, (sockaddr*)&sn, sizeof(sn));   if(j>4) break; Sleep(10); }   // ʵ������Ӽ��� ......? ��Ч��!

if (n == SOCKET_ERROR){ qTrace("\r\n%d�� connect ʧ��, ���� %d", j, WSAGetLastError());  closesocket(soc);  return INVALID_SOCKET;  }  
else {  Printf("\r\nHost connected\t[%s]\t soc=0x%X\t j=%d\r\n\r\n",  host, soc, j);  } 



#endif    // CONNECT_HOST






#if CONNECT_SSL|1

SSL_CTX* ctx=0;  
SSL*ssl=0; 

if (port == 443) {


// ����SSL������Ϣ .  ����SSL�ļ���/HASH�㷨 ...  

SSL_library_init(); \
ERR_load_BIO_strings();  \
SSL_load_error_strings();  \
OpenSSL_add_all_algorithms();


const SSL_METHOD *meth = SSLv23_client_method();	// �ͻ���, �����ѡ��SSLv23_server_method()   //  ssl Э��汾2��3  

ctx = SSL_CTX_new(meth);	// �����µ�SSL������ 
if( !ctx ) { qTrace("\r\nSSL_CTX_new error %d!\r\n", GetLastError() ); return 0; }
		
ssl = SSL_new(ctx);         // ����SSL 
if( !ssl ) {  qTrace("\r\nSSL_new error %d", WSAGetLastError());  return 0; }

// SSL_CTX_load_verify_locations(ctx,ROOTCERTF,NULL);  SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, 0);

if(!SSL_set_tlsext_host_name(ssl, host)){   Printf( "\n\nWARNING: failed to configure server name indication (SNI) " "TLS extension\n\n"); }

SSL_set_fd(ssl,soc);          // ��SSL��TCP SOCKET ���� 
	
int ret = SSL_connect(ssl);   // SSL���� 


if(ret==1) Printf("\r\n\r\nSSL_connect successful! [%s]\r\n\r\n", host);


if (ret == -1) {

int ic=0; 
while(ret==-1){  

Printf("\r\nSSL_connect=%d,  detail= %d ", ret, SSL_get_error(ssl, ret)  );
// SSL_ERROR_WASSL_ERROR_SYSCALL=5

Sleep(100); 
ret = SSL_connect(ssl);    

ic++; if(ic>30) break;  
}

if(ret == -1) { Printf( "\r\nSSL_connect unsuccessful! \r\n"  );  return 0; }
else            Printf("\r\n\r\nSSL_connect successful after trying! [%s]\r\n\r\n", host);
	
}    // if (ret == -1)
	


}  // if(port==443)  
	
#endif    // CONNECT_SSL






const int iPK=1024;  
int nc=1024*100;       // �ڴ�������� 100K 
char*szt = (char*)malloc(nc+1*32);  *szt=0; 


// string  reqInfo = "GET " +(string)othPath+ " HTTP/1.1\r\nHost: " + (string)host + "\r\nConnection:Close\r\n\r\n";  
int ic=sprintf(szt, "GET %s HTTP/1.1\r\n"  \
//"Accept: */*\r\n"             // stream << "Accept-Encoding: gzip, deflate, br\r\n";  // ��Ҫ����, ���򻹵ö�һ������Ĳ���
"Host:%s\r\n"                // "Host:%s\r\n" 
//"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134\r\n" 
"Connection:Close\r\n\r\n",   //  "Connection: Keep-Alive\r\n" 
uri, host);   


// string s = stream.str(); const char *sendData = s.c_str();	strcpy(szt,s.c_str()); ir=strlen(szt);  

int ir =0;   

if(port==443) ir=SSL_write(ssl,szt,ic);    //  
else          ir=send(soc,szt,ic,0);       //  ����������http�����ַ��� ......   
if(ir== -1){ qTrace("SSL write error !");    delete[] uri, host; free(szt); closesocket(soc); return 0;  }  


Printf("\r\nrequest sent�� %d / %d: \r\n%s\r\n", ir,ic, szt);



int ict=0;
ic=0;       // ic ת���ڼ����ڴ�������     



#if RECV_PAGE|1


if(port==443){

while( ( ir=SSL_read(ssl,szt+ict,iPK) )   >0  ){   // if(ir<=0){ printf("\r\nrecv =0 ... \r\n\r\n"); break; }

ict += ir;  

if( ict+iPK>=nc){   ic++;   if(0)Printf("\r\n%d\t  ir=%d, ict+iPK=%dK , nc=%dK ",  ic, ir,  ict+iPK , nc/1024);   // ������ 1K �������� 
nc+=iPK*100;  szt = (char*)realloc(szt, nc+128);    
}  

szt[ict] = 0;  // Printf("ic=%d\r\n", ic);
if(ic>1024) break;    // ���ݹ���!  
}  // while  



}else{


while( (ir =recv(soc,szt+ict,iPK,0) ) >0){   // if(ir<=0){ printf("\r\nrecv =0 ... \r\n\r\n"); break; }

ict += ir;  

if( ict+iPK>=nc){   ic++;   if(0)printf("\r\n%d\t  ir=%d, ict+iPK=%dK , nc=%dK ",  ic, ir,  ict+iPK , nc/1024);   // ������ 1K �������� 
nc+=iPK*100;  szt = (char*)realloc(szt, nc+128);    
}  

szt[ict] = 0;  // printf("ir=%d\r\n", ir);
if(ic>1024) break;    // ���ݹ���!  
}  // while  


}  // if(port==443)







// closesocket(scr);   // ������Դ�ļ���Ҫ��! Connection:Close ���ùر�. 
Printf("\r\nic=%d\t  ict=%d, nc=%dK \r\n\r\n",  ic,  ict, nc/1024); 

#endif  // RECV_PAGE 


GetLinks(szt, pa->URL, pa->szHtm);





FILE*fp=fopen(pa->szHtm,"wb");
char*p= strstr(szt,"\r\n\r\n");  if(p) p+=4; else p=szt;  
fprintf(fp, "%s\r\n", p); 
fclose(fp);
Printf("OK\r\n");
	





#if OPEN_PAGE|1

ShellExecuteA(0, "open", pa->szHtm, 0,0,1);

#else

// ShellExecute(0,0,szHtm,0,0,SW_SHOWNORMAL);  // ShellExecute(0L, "open", "a.html",0, 0,SW_SHOWNORMAL );  ShellExecute(0,"open","iexplore","a.html",0,SW_SHOW);

InvalidateRect(GetMainDlg(),0,1);
IE_open(pa->szHtm); 

#endif  // OPEN_PAGE








#if CLEAN_SSL|1

if(port==443){ 
SSL_shutdown(ssl);	// �ر�SSL�׽��� 
SSL_free(ssl);      // �ͷ�SSL�׽��� 
SSL_CTX_free(ctx);	// �ͷ�SSL�Ự���� 
}    //  if(port==443)   

#endif  


closesocket(soc);  
WSACleanup();

free( szt );
return ict;
}
 
 








 




 





