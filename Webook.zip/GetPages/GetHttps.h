



#ifndef _GETHTTPS_H_
#define _GETHTTPS_H_    // #endif  // _GETHTTPS_H_ //

// �ṹ����HTTPPROXY.CPP��ʵ��
#ifdef  _GETHTTPS_CPP_    // #define   _GETHTTPS_CPP_ //
#define GETHTTPS_EXTERN 
#else 
#define GETHTTPS_EXTERN extern 
#endif  // _GETHTTPS_CPP_ //

#include <Windows.h>
 


int ParseURL(const char* url, char* ptr_host, char* ptr_uri);

int GetURI(const char*URL);  


DWORD WINAPI GetHttps(void*pa);    // const char*URL=0, const char*Save=0 



#endif  // _GETHTTPS_H_ //






